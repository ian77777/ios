//
//  NSObject+Value.h
//  HuiBeiLifeMerchant
//
//  Created by niu mu on 13-8-24.
//  Copyright (c) 2013年 huiyinfeng. All rights reserved.
//

#define HBMWithDictH(prefix) \
+ (instancetype)prefix##WithDict:(NSDictionary *)dict;

#define HBMWithDictM(className, prefix) \
+ (instancetype)prefix##WithDict:(NSDictionary *)dict \
{ \
    className *obj = [[self alloc] init]; \
    [obj setValues:dict]; \
    return obj; \
}

#define HBMSetter(className, subfix, param) \
- (void)set##subfix:(id)param \
{ \
    if ([param isKindOfClass:[NSDictionary class]]) { \
        _##param = [className param##WithDict:param]; \
    } else { \
        _##param = param; \
    } \
}

#define HBMCodingM \
- (id)initWithCoder:(NSCoder *)decoder \
{ \
    if (self = [super init]) { \
        [self decode:decoder]; \
    } \
    return self; \
} \
 \
- (void)encodeWithCoder:(NSCoder *)encoder \
{ \
    [self encode:encoder]; \
}

#import <Foundation/Foundation.h>

@interface NSObject (Value)
// 设置数据
- (void)setValues:(NSDictionary *)values;
- (NSDictionary *)values;
- (void)decode:(NSCoder *)decoder;
- (void)encode:(NSCoder *)encoder;
+ (id)performSelector:(SEL)selector withObjects:(NSArray *)objects;
@end