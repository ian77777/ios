//
//  HBMHomeModel.m
//  HuiBeiLifeMerchant
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 huiyinfeng. All rights reserved.
//

#import "HBMEmployeeModel.h"

@implementation HBMEmployeeModel
HBMCodingM

+(instancetype)employeeModelWithHead:(NSData *)head name:(NSString *)name department:(NSString *)department position:(NSString *)position identifer:(int)identifer{
    HBMEmployeeModel *hm = [[self alloc] init];
    hm.headImage = head;
    hm.name = name;
    hm.department = department ;
    hm.identifer = identifer ;
    return hm;
}

@end
