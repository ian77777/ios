//
//  HBMHomeModel.h
//  HuiBeiLifeMerchant
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 huiyinfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HBMEmployeeModel : NSObject
@property (nonatomic, assign) Class vcClass;
@property(strong,nonatomic)NSString* name ;
@property(strong,nonatomic)NSString* department ;
@property(strong,nonatomic)NSString* position ;
@property(assign,nonatomic)int identifer ;
@property(strong,nonatomic)NSData* headImage ;

@property(assign,nonatomic) BOOL isAddNew ;
//+ (instancetype)employeeModelWithIcon:(NSString *)icon title:(NSString *)title vcClass:(Class)vcClass;

+ (instancetype)employeeModelWithHead:(NSData*)head name:(NSString*)name department:(NSString*)department position:(NSString*)position identifer:(int)identifer;
@end
