//
//  EmployeeTool.m
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import "EmployeeTool.h"
#import "HBMEmployeeModel.h"
@interface EmployeeTool(){
    NSArray* _employees ;
}

@end
@implementation EmployeeTool
single_for_implementation(EmployeeTool)

#pragma mark - 添加新员工
-(BOOL)addNewEmployee:(HBMEmployeeModel *)employee{
    if (!_employees) {
        _employees = [NSKeyedUnarchiver unarchiveObjectWithFile:kFilePath];
    }
    if (_employees == nil){
        _employees = [NSArray array];
    };
    for (HBMEmployeeModel* emp in _employees) {
        if (emp.identifer == employee.identifer) {
            return NO ;
        }
    }
    NSMutableArray* temp = [NSMutableArray arrayWithArray:_employees];
    [temp addObject:employee];
    [NSKeyedArchiver archiveRootObject:temp toFile:kFilePath];
    NSLog(@"save ok!");
    return YES ;
}

#pragma mark - 更新员工
-(BOOL)updateEmployee:(HBMEmployeeModel *)employee{
    NSMutableArray* temp = [NSMutableArray arrayWithArray:_employees];
    for (HBMEmployeeModel* emp in _employees) {
        if (emp.identifer == employee.identifer) {
            [temp removeObject:emp];
            [temp addObject:employee];
            _employees = temp ;
            [NSKeyedArchiver archiveRootObject:temp toFile:kFilePath];
            return YES ;
        }
    }
    return NO ;
}

#pragma mark - 删除员工
-(void)deleteEmployee:(HBMEmployeeModel *)employee{
    NSMutableArray* temp = [NSMutableArray arrayWithArray:_employees];
    for (HBMEmployeeModel* emp in _employees) {
        if (emp.identifer == employee.identifer) {
            [temp removeObject:emp];
            _employees = temp ;
            [NSKeyedArchiver archiveRootObject:temp toFile:kFilePath];
        }
    }
}

#pragma mark - 加载所有的员工信息
-(NSArray*)loadAllEmployee{
    _employees = [NSKeyedUnarchiver unarchiveObjectWithFile:kFilePath];
    return _employees ;
}

#pragma mark - 查找员工
-(HBMEmployeeModel *)findEmployeeById:(int)identifer{
    for (HBMEmployeeModel* emp in _employees) {
        if (emp.identifer == identifer) {
            return emp ;
        }
    }
    return nil ;
}
@end
