//
//  EmployeeTool.h
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "singleton.h"
@class HBMEmployeeModel ;
@interface EmployeeTool : NSObject
singleton_for_interface(EmployeeTool)
@property(strong,nonatomic) HBMEmployeeModel* currEmp;

//添加新员工
-(BOOL)addNewEmployee:(HBMEmployeeModel*)employee;
//更新员工
-(BOOL)updateEmployee:(HBMEmployeeModel*)employee;
//删除员工
-(void)deleteEmployee:(HBMEmployeeModel*)employee;
//加载所有的员工信息
-(NSMutableArray*)loadAllEmployee;
//依据标示查找员工信息
-(HBMEmployeeModel*)findEmployeeById:(int)identifer;

@end
