//
//  HBMHomeCell.h
//  HuiBeiLifeMerchant
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 huiyinfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HBMEmployeeModel;
@interface HBMHomeCell : UICollectionViewCell
@property (nonatomic, strong) HBMEmployeeModel *employeeModel;
@end
