//
//  HBMHomeHeadView.h
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-21.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HBMHomeHeadView : UIView
@property (strong, nonatomic) IBOutlet UILabel *totalLabel;

+(HBMHomeHeadView*)headerView ;
@end
