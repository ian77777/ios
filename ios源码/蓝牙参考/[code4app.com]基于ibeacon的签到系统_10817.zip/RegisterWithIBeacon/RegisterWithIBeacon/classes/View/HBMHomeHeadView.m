//
//  HBMHomeHeadView.m
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-21.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import "HBMHomeHeadView.h"

@implementation HBMHomeHeadView

+(HBMHomeHeadView*)headerView{
    HBMHomeHeadView* view = [[[NSBundle mainBundle]loadNibNamed:@"HBMHomeHeadView" owner:self options:nil]lastObject];
    view.backgroundColor = HBMGlobalBg ;
    return view;
}
@end
