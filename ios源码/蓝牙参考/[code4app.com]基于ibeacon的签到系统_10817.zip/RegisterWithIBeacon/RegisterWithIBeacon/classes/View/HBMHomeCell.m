//
//  HBMHomeCell.m
//  HuiBeiLifeMerchant
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 huiyinfeng. All rights reserved.
//

#import "HBMHomeCell.h"
#import "HBMEmployeeModel.h"

@interface HBMHomeCell()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *titleView;

@end

@implementation HBMHomeCell

- (void)setEmployeeModel:(HBMEmployeeModel *)employeeModel
{
    _employeeModel = employeeModel;
    
    // 1.图标
    _iconView.image = [UIImage imageWithData:employeeModel.headImage];
    
    // 2.标题
    _titleView.text = employeeModel.name;
}
@end
