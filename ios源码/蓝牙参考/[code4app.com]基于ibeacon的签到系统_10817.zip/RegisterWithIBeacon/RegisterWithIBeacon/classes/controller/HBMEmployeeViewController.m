//
//  HBMEmployeeViewController.m
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import "HBMEmployeeViewController.h"
#import "HBMEmployeeModel.h"
#import "EmployeeTool.h"
@interface HBMEmployeeViewController ()<UIActionSheetDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
     ;
    UIImage* _selectedImg ;
}
@end

@implementation HBMEmployeeViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.headView addTarget:self action:@selector(chooseHead) forControlEvents:UIControlEventTouchUpInside];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
}

#pragma mark - 取消添加
- (IBAction)cancelClick {
    [self dismissViewControllerAnimated:YES completion:^{
        return ;
    }];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 添加新员工
- (IBAction)addNewClick {
    NSString* name = self.nameLabel.text ;
    NSString* department = self.departmentLabel.text ;
    int identifer = [self.identifierLabel.text intValue];
    NSString* position = self.positionLabel.text ;
    
    NSData* headView ;
    if (_selectedImg == nil) {
        UIImage* img = [UIImage imageNamed:@"personal_head_default"];
        headView = UIImagePNGRepresentation(img);
    }
    else{
        headView = UIImagePNGRepresentation(_selectedImg);
    }
    HBMEmployeeModel* employee = [HBMEmployeeModel employeeModelWithHead:headView name:name department:department position:position identifer:identifer];
    employee.isAddNew = YES ;
    //保存到全局变量
    [EmployeeTool sharedEmployeeTool].currEmp = employee ;
    
    //保存入库
    [[EmployeeTool sharedEmployeeTool]addNewEmployee:employee];
    [self cancelClick];
}

#pragma mark - 编辑头像
-(void)chooseHead{
    UIActionSheet* sheet = [[UIActionSheet alloc]initWithTitle:@"头像编辑" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"相册获取", nil];
    [sheet showInView:self.view];
}

#pragma mark - UIActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    // 1. 实例化照片选择控制器
    UIImagePickerController *picker = [[UIImagePickerController alloc]init];
    // 2.1 允许编辑
    [picker setDelegate:self];
    [picker setAllowsEditing:YES];
    if (buttonIndex == 0) {
        //拍照
        // 2. 设置选择控制器的属性
        [picker setSourceType:UIImagePickerControllerSourceTypeCamera];
    }
    else if (buttonIndex == 1){
        //相册获取
        [picker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    }
    else return;
    // 3. 显示选择控制器
    [self presentViewController:picker animated:YES completion:nil];
}


#pragma mark - 照片选择代理方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self dismissViewControllerAnimated:YES completion:^{
        _selectedImg = info[@"UIImagePickerControllerEditedImage"];
        
        [self.headView setBackgroundImage:_selectedImg forState:UIControlStateNormal];
    }];
}
@end
