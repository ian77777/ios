//
//  HBMSyncViewController.m
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-23.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import "HBMSyncViewController.h"
#import <GameKit/GameKit.h>
#import "EmployeeTool.h"
#import "HBMEmployeeModel.h"
#import <MultipeerConnectivity/MultipeerConnectivity.h>
static NSString * const kServiceName = @"multipeer";
static NSString * const kMessageKey = @"message";

@interface HBMSyncViewController ()<MCBrowserViewControllerDelegate,MCSessionDelegate>
{
    MCPeerID* _peerId ;
    MCSession* _session ;
    MCBrowserViewController* _broswerController ;
    MCAdvertiserAssistant* _advertiser ;
    //是否发送数据
    NSMutableData* _tempData ;
    
}
@end

@implementation HBMSyncViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    _tempData = [NSMutableData data];
}

#pragma mark - 代理方法

#pragma mark - 开始发送
- (IBAction)startSendClick{
    _peerId = [[MCPeerID alloc]initWithDisplayName:@"发送者"];
    _session = [[MCSession alloc]initWithPeer:_peerId];
    _session.delegate = self ;
    
    _advertiser = [[MCAdvertiserAssistant alloc]initWithServiceType:kServiceName discoveryInfo:nil session:_session];
    [_advertiser start];
    self.indicatorView.hidden = NO ;
}


#pragma mark -完成同步
- (IBAction)syncOKClick {
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

#pragma mark - 开始接收
- (IBAction)startReceive {
    _peerId = [[MCPeerID alloc]initWithDisplayName:@"接收者"];
    _session = [[MCSession alloc]initWithPeer:_peerId];
    _session.delegate = self ;
    
    _broswerController = [[MCBrowserViewController alloc]initWithServiceType:kServiceName session:_session];
    _broswerController.delegate = self ;
    [self presentViewController:_broswerController animated:YES completion:^{
        
    }];
}

- (IBAction)beginTransort {
    //发送数据
    NSError *error;
    NSArray* array = [[EmployeeTool sharedEmployeeTool]loadAllEmployee];

    NSData* data = [NSKeyedArchiver archivedDataWithRootObject:array];
    
    [_session sendData:data toPeers:[_session connectedPeers] withMode:MCSessionSendDataReliable error:&error];
}
#pragma mark - MCBrowserViewControllerDelegate

- (void)browserViewControllerDidFinish:(MCBrowserViewController *)browserViewController {
    [self dismissViewControllerAnimated:YES completion:^{
        [_broswerController.browser stopBrowsingForPeers];
    }];
}

- (void)browserViewControllerWasCancelled:(MCBrowserViewController *)browserViewController {
    [self dismissViewControllerAnimated:YES completion:^{
        [_broswerController.browser stopBrowsingForPeers];
    }];
}

#pragma mark - MCSessionDelegate 代理方法
-(void)session:(MCSession *)session didReceiveData:(NSData *)data fromPeer:(MCPeerID *)peerID{
    NSArray* empArr = [NSKeyedUnarchiver unarchiveObjectWithData:data] ;
    if (empArr == nil) {
        return ;
    }
    NSLog(@"接收完毕!");
    for (HBMEmployeeModel* employee in empArr) {
        NSLog(@"传送中");
        employee.isAddNew = YES ;
        [EmployeeTool sharedEmployeeTool].currEmp = employee;
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_sync(queue, ^{
            [[EmployeeTool sharedEmployeeTool]addNewEmployee:employee];
        });
    }
}

-(void)session:(MCSession *)session peer:(MCPeerID *)peerID didChangeState:(MCSessionState)state{
    switch (state) {
        case MCSessionStateConnected: {
            dispatch_async(dispatch_get_main_queue(), ^{
                _indicatorView.hidden = YES ;
                self.beginTransportBtn.hidden = NO ;
            });
            // This line only necessary for the advertiser. We want to stop advertising our services
            // to other browsers when we successfully connect to one.
            [_advertiser stop];
            break;
        }
        case MCSessionStateNotConnected: {
            dispatch_async(dispatch_get_main_queue(), ^{
                _indicatorView.hidden = NO;
            });
            break;
        }
        default:
            break;
    }
}

// Required MCSessionDelegate protocol methods but are unused in this application.

- (void)                      session:(MCSession *)session
    didStartReceivingResourceWithName:(NSString *)resourceName
                             fromPeer:(MCPeerID *)peerID
                         withProgress:(NSProgress *)progress {
    
}

- (void)     session:(MCSession *)session
    didReceiveStream:(NSInputStream *)stream
            withName:(NSString *)streamName
            fromPeer:(MCPeerID *)peerID {
    
}

- (void)                       session:(MCSession *)session
    didFinishReceivingResourceWithName:(NSString *)resourceName
                              fromPeer:(MCPeerID *)peerID
                                 atURL:(NSURL *)localURL
                             withError:(NSError *)error {
    
}

@end
