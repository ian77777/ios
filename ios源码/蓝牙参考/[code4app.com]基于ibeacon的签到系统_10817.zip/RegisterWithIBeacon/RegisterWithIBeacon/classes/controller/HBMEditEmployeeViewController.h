//
//  HBMEditEmployeeViewController.h
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-23.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HBMEmployeeModel ;
@interface HBMEditEmployeeViewController : UITableViewController

@property(strong,nonatomic) HBMEmployeeModel* emp ;

@property (strong, nonatomic) IBOutlet UITextField *nameLabel;
@property (strong, nonatomic) IBOutlet UIButton *headView;
@property (strong, nonatomic) IBOutlet UITextField *departmentLabel;
@property (strong, nonatomic) IBOutlet UITextField *positionLabel;
@property (strong, nonatomic) IBOutlet UITextField *identiferLabel;

- (IBAction)updateClick;
- (IBAction)deleteClick;
- (IBAction)cancelClick;

@end
