//
//  HBMSyncViewController.h
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-23.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HBMSyncViewController : UIViewController
- (IBAction)startSendClick;
- (IBAction)syncOKClick;
- (IBAction)startReceive;
- (IBAction)beginTransort;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *indicatorView;
@property (strong, nonatomic) IBOutlet UIButton *beginTransportBtn;


@end
