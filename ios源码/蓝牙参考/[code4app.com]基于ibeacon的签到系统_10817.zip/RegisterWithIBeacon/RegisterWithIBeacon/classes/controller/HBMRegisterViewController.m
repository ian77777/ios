//
//  HBMRegisterViewController.m
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-23.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import "HBMRegisterViewController.h"
#import "HBMEmployeeModel.h"
#import "EmployeeTool.h"
#import <CoreLocation/CoreLocation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface HBMRegisterViewController ()<CLLocationManagerDelegate,CBPeripheralManagerDelegate>
{
    CLBeaconRegion* _myBeaconRegion ;
    NSDictionary* _myBeaconData ;
    CBPeripheralManager* _peripheralMsg ;
}

@end

@implementation HBMRegisterViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.myInfoView.backgroundColor = HBMGlobalBg ;
}

#pragma mark - 点击签到
- (IBAction)registerClick {
    //初始化 区域
    NSUUID* uuid =[[NSUUID alloc]initWithUUIDString:kUUID];
    _myBeaconRegion = [[CLBeaconRegion alloc]initWithProximityUUID:uuid major:_major minor:[kMinor intValue] identifier:kIndetifier];
    //发射广播信号
    _myBeaconData = [_myBeaconRegion peripheralDataWithMeasuredPower:nil];
    _peripheralMsg = [[CBPeripheralManager alloc]initWithDelegate:self queue:nil options:nil];
}

#pragma mark - 代理方法
-(void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral{
    if (peripheral.state == CBPeripheralManagerStatePoweredOn)
    {
        // Bluetooth is on
        // Update our status label
        self.registerStatusLabel.text = @"签到中...";
        // Start broadcasting
        [_peripheralMsg startAdvertising:_myBeaconData];
    }
    else if (peripheral.state == CBPeripheralManagerStatePoweredOff)
    {
        // Update our status label
        self.registerStatusLabel.text = @"请检查蓝牙状态";
        // Bluetooth isn't on. Stop broadcasting
        [_peripheralMsg stopAdvertising];
    }
    else if (peripheral.state == CBPeripheralManagerStateUnsupported)
    {
        self.registerStatusLabel.text = @"不支持的设备";
    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSNumber* identifier = [[NSUserDefaults standardUserDefaults] objectForKey:kCurrUser] ;
    if (identifier != nil) {
        self.settingBtn.hidden = YES ;
        self.myInfoView.hidden = NO ;
        HBMEmployeeModel* emp = [[EmployeeTool sharedEmployeeTool]findEmployeeById:[identifier intValue]];
        _major = emp.identifer ;
        self.nameLabel.text = [NSString stringWithFormat:@"%@",emp.name] ;
        self.identiferLabel.text = [NSString stringWithFormat:@"编号 %d",emp.identifer] ;
        self.headView.image = [UIImage imageWithData:emp.headImage];
    }
    else{
        self.settingBtn.hidden = NO ;
        self.myInfoView.hidden = YES ;
    }
}
@end
