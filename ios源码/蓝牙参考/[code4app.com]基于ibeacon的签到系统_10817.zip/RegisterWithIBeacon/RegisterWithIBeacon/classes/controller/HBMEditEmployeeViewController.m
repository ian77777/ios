//
//  HBMEditEmployeeViewController.m
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-23.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import "HBMEditEmployeeViewController.h"
#import "HBMEmployeeModel.h"
#import "EmployeeTool.h"
@interface HBMEditEmployeeViewController ()<UIAlertViewDelegate>

@end

@implementation HBMEditEmployeeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.title = @"员工信息" ;
    self.nameLabel.text = _emp.name ;
    self.departmentLabel.text = _emp.department ;
    self.positionLabel.text = _emp.position ;
    self.identiferLabel.text = [NSString stringWithFormat:@"%d",_emp.identifer] ;
    [self.headView setBackgroundImage:[UIImage imageWithData:_emp.headImage] forState:UIControlStateNormal];
}

- (IBAction)updateClick {
    NSString* name = self.nameLabel.text ;
    NSString* department = self.departmentLabel.text ;
    int identifer = [self.identiferLabel.text intValue];
    NSString* position = self.positionLabel.text ;
    _emp.name = name ;
    _emp.department = department ;
    _emp.position = position ;
    _emp.identifer = identifer ;
    [[EmployeeTool sharedEmployeeTool]updateEmployee:_emp];
    [self cancelClick];
}

- (IBAction)deleteClick {
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:@"警告" message:@"删除该员工信息" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert show];
}

#pragma mark - 代理
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        _emp.isAddNew = NO ;
        [EmployeeTool sharedEmployeeTool].currEmp = _emp ;
        [self cancelClick];
    }
}

- (IBAction)cancelClick {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
