//
//  HBMVCardChooseViewController.m
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-23.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import "HBMVCardChooseViewController.h"
#import "EmployeeTool.h"
#import "HBMEmployeeModel.h"
@interface HBMVCardChooseViewController ()
{
    NSArray* _employeeModes ;
}
@end

@implementation HBMVCardChooseViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _employeeModes = [[EmployeeTool sharedEmployeeTool]loadAllEmployee];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return _employeeModes.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
    HBMEmployeeModel* employee = _employeeModes[indexPath.row];
    cell.imageView.image = [[UIImage alloc]initWithData:employee.headImage];
    cell.imageView.contentMode = UIViewContentModeScaleAspectFit ;
    cell.textLabel.text = employee.name ;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d",employee.identifer] ;
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60.f ;
}

#pragma mark - 选中
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HBMEmployeeModel* emp = _employeeModes[indexPath.row];
    
    //保存选中的员工编号
    [[NSUserDefaults standardUserDefaults]setObject:[NSNumber numberWithInt:emp.identifer] forKey:kCurrUser];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [self.navigationController popViewControllerAnimated:YES];
}

@end
