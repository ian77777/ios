//
//  HBMEmployeeViewController.h
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HBMEmployeeViewController : UITableViewController

@property (strong, nonatomic) IBOutlet UITextField *nameLabel;
@property (strong, nonatomic) IBOutlet UIButton *headView;

@property (strong, nonatomic) IBOutlet UITextField *departmentLabel;

@property (strong, nonatomic) IBOutlet UITextField *positionLabel;

@property (strong, nonatomic) IBOutlet UITextField *identifierLabel;

- (IBAction)cancelClick;

- (IBAction)addNewClick;

@end
