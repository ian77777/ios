//
//  HBMHomeViewController.m
//  HuiBeiLifeMerchant
//
//  Created by Zhu Lizhe on 14-2-22.
//  Copyright (c) 2014年 huiyinfeng. All rights reserved.
//

#import "HBMHomeViewController.h"
#import "HBMHomeCell.h"
#import "HBMEmployeeModel.h"
#import "HBMHomeHeadView.h"
#import "EmployeeTool.h"
#import "HBMEditEmployeeViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <CoreBluetooth/CoreBluetooth.h>


@interface HBMHomeViewController ()<CLLocationManagerDelegate>
{
    NSMutableArray* _employeeModes ; //模型数据
    NSMutableArray* _employeeLater ; //迟到数据
    NSMutableArray* _employeeRegistered ; //签到数据
    UIBarButtonItem *_loginItem; // 右上角的登录item
    
    CLBeaconRegion* _myBeaconRegion ;
    NSDictionary* _myBeaconData ;
    CLLocationManager* _locationlMsg ;
    
    int _currCount ; //当前总人数
}
@end

@implementation HBMHomeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // 1.初始化模型数据
    [self setupModels];
    // 2.其他设置
    [self setupOther];
    [self.segmentControl addTarget:self action:@selector(segmentChange:) forControlEvents:UIControlEventValueChanged];
    //初始化点名
    [self initCalltheRoll];
    //默认 启动点名模式
    [self startCalltheRoll];
}

#pragma mark - 初始化点名
-(void)initCalltheRoll{
    //初始化 区域
    NSUUID* uuid =[[NSUUID alloc]initWithUUIDString:kUUID];
    _myBeaconRegion = [[CLBeaconRegion alloc]initWithProximityUUID:uuid  identifier:kIndetifier];
    _locationlMsg = [[CLLocationManager alloc]init];
    _locationlMsg.delegate = self ;
}

#pragma mark - 启动点名
-(void)startCalltheRoll{
    [_locationlMsg startMonitoringForRegion:_myBeaconRegion];
    [_locationlMsg startRangingBeaconsInRegion:_myBeaconRegion];
}

#pragma mark 其他设置
- (void)setupOther
{
    // 1.设置背景
    self.collectionView.backgroundColor = [UIColor whiteColor];
}

#pragma mark 初始化模型数据
- (void)setupModels
{
    _employeeModes = [[EmployeeTool sharedEmployeeTool]loadAllEmployee];
    _currCount = _employeeModes.count ;
    if (_employeeRegistered == nil) {
        _employeeRegistered = [NSMutableArray array];
    }
    if (_employeeLater == nil) {
        _employeeLater = _employeeModes;
    }
    HBMEmployeeModel* tempEmp = [EmployeeTool sharedEmployeeTool].currEmp;
    if (tempEmp != nil) {
        //添加或者删除了员工
        if (tempEmp.isAddNew) {
            [_employeeLater addObject:tempEmp];
        }
        else{
            //已经存在该员工，删除模式
            [_employeeModes removeObject:tempEmp];
            if ([_employeeLater containsObject:tempEmp]) {
                [_employeeLater removeObject:tempEmp];
            }
            else{
                [_employeeRegistered removeObject:tempEmp];
            }
            [[EmployeeTool sharedEmployeeTool]deleteEmployee:tempEmp];
            _currCount -- ;
        }
    }
    [EmployeeTool sharedEmployeeTool].currEmp = nil ;
    [self.collectionView reloadData];
}

#pragma mark - collectionView数据源\代理方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section == 0) {
        return _employeeRegistered.count;
    }
    return _employeeLater.count ;
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 2 ;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // 1.获得cell
    static NSString *ID = @"home";
    HBMHomeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    // 2.传递模型
    if (indexPath.section == 0) {
        cell.employeeModel = _employeeRegistered[indexPath.row];
    }
    else{
        cell.employeeModel = _employeeLater[indexPath.row];
    }
    // 2.传递模型
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    // 1.获得头部
    static NSString *ID = @"header";
    UICollectionReusableView *header = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:ID forIndexPath:indexPath];
    // 2.添加子控件
    HBMHomeHeadView* head = [HBMHomeHeadView headerView] ;
    NSString* info = nil ;
    if (indexPath.section == 0) {
        info = [NSString stringWithFormat:@"应到人数：%d\n实到人数：%d",_currCount,_employeeRegistered.count];
    }
    else{
        info = [NSString stringWithFormat:@"迟到人员：%d",_employeeLater.count];
    }
    head.totalLabel.text = info ;
    [header addSubview:head];
    return header;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    HBMEmployeeModel* emp = indexPath.section?_employeeLater[indexPath.row]:_employeeRegistered[indexPath.row] ;
    [self performSegueWithIdentifier:@"editEmployee" sender:emp];
}

#pragma mark - 即将跳转
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"editEmployee"]) {
        HBMEditEmployeeViewController* dest = segue.destinationViewController ;
        dest.emp = sender ;
    }
}

#pragma mark - 扫描模式改变
-(void)segmentChange:(UISegmentedControl*)sender{
    if (sender.selectedSegmentIndex == 0) {
        //点名模式
    }
    else{
        //签到模式
        [self performSegueWithIdentifier:@"modeBroadcast" sender:nil];
    }
}

-(void)viewWillAppear:(BOOL)animated{
    //设置当前的默认模式为点名模式
    [self.segmentControl setSelectedSegmentIndex:0];
    
    [self setupModels];
    [self.collectionView reloadData];
}

#pragma mark -
-(void)locationManager:(CLLocationManager *)manager didRangeBeacons:(NSArray *)beacons inRegion:(CLBeaconRegion *)region{
    //发现签到者
    NSMutableArray* employeesToDelete = [NSMutableArray array];
    for (CLBeacon* beacon in beacons) {
        for (HBMEmployeeModel* emp in _employeeModes) {
            if ([beacon.major intValue] == emp.identifer) {
                for (HBMEmployeeModel* emp in _employeeLater) {
                    if (emp.identifer == [beacon.major intValue]) {
                        [employeesToDelete addObject:emp];
                    }
                }
            }
        }
    }
    //1:加入签到数组
    [_employeeRegistered addObjectsFromArray:employeesToDelete];
    [_employeeLater removeObjectsInArray:employeesToDelete];
    //2:从迟到数组中删除
    [self.collectionView reloadData];
}

@end
