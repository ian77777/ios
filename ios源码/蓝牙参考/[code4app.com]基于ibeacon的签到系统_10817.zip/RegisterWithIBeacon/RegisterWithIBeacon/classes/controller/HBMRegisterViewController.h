//
//  HBMRegisterViewController.h
//  RegisterWithIBeacon
//
//  Created by Zhu Lizhe on 14-2-23.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HBMRegisterViewController : UIViewController
- (IBAction)registerClick;

@property (strong, nonatomic) IBOutlet UIView *settingBtn;
@property (strong, nonatomic) IBOutlet UIView *myInfoView;
@property (strong, nonatomic) IBOutlet UIImageView *headView;
@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UILabel *identiferLabel;
@property (strong, nonatomic) IBOutlet UILabel *registerStatusLabel;

@property(assign,nonatomic) int major ;

@end
