//
//  HBMHomeViewController.h
//  HuiBeiLifeMerchant
//
//  Created by niu mu on 14-1-5.
//  Copyright (c) 2014年 huiyinfeng. All rights reserved.
//  首页

#import <UIKit/UIKit.h>

@interface HBMHomeViewController : UICollectionViewController
@property (strong, nonatomic) IBOutlet UISegmentedControl *segmentControl;

@end
