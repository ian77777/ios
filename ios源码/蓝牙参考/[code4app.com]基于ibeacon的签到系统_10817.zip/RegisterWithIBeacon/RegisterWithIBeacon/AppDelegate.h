//
//  AppDelegate.h
//  RegisterWithIBeacon
//
//  Created by zhulizhe on 14-2-21.
//  Copyright (c) 2014年 HuiBei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
