RegisterWithIBeacon
====
基于ibeacon的点名系统