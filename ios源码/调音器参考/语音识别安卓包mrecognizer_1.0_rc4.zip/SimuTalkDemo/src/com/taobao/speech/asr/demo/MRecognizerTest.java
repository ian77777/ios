package com.taobao.speech.asr.demo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.taobao.speech.asr.MRecognizer;
import com.taobao.speech.asr.RecognizeListener;
import com.taobao.speech.asr.StageListener;
import com.taobao.speech.utils.JoyPrint;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: yinshang
 * Date: 13-11-1
 * Time: 10:59
 * To change this template use File | Settings | File Templates.
 */
public class MRecognizerTest extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_test_mrecognizer);
        mResultEdit = (EditText) findViewById(R.id.edit_result);
        mStartButton = (Button) findViewById(R.id.start);
        mMRecognizer = new MRecognizer(this, mRecognizeListener,mStageListener,"tb","123456");
        mMRecognizer.openLog(true);
        mMRecognizer.setMaxStallTime(1000);
        mMRecognizer.setMinRecordTime(1000);
        mMRecognizer.setMinMuteValue(1200);
        mMRecognizer.checkService();
        initStartButton(mStartButton);
    }

    private boolean isStarted = false;
    private long startTime;
    private void initStartButton(final Button button) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTime = System.currentTimeMillis();
                mMRecognizer.start();

            }
        });
    }

    private RecognizeListener mRecognizeListener = new RecognizeListener() {
        @Override
        public void onRecognizingResult(int status, RecognizedResult result) {
            switch (status) {
                case MRecognizer.ErrorCode.SUCCESS:
                    mResultEdit.setText(mResultEdit.getText().toString() + result.recognizedString);
                    break;
                case MRecognizer.ErrorCode.RECOGNIZE_ERROR:
                    Toast.makeText(MRecognizerTest.this,"recognizer error",Toast.LENGTH_LONG).show();
                    break;
                case MRecognizer.ErrorCode.RECORDING_ERROR:
                    Toast.makeText(MRecognizerTest.this,"recording error",Toast.LENGTH_LONG).show();
                    break;
                case MRecognizer.ErrorCode.NOTHING:
                    Toast.makeText(MRecognizerTest.this,"nothing",Toast.LENGTH_LONG).show();
                    break;
            }
        }

        @Override
        public void onServiceStatChanged(boolean isAvailable,boolean isRpcAvailable) {
            if(isAvailable) {
                mStartButton.setVisibility(View.VISIBLE);
            } else {
                mStartButton.setVisibility(View.INVISIBLE);
            }
        }
    } ;

    private StageListener mStageListener = new StageListener() {
        @Override
        public void onStartRecognizing(MRecognizer recognizer) {
            super.onStartRecognizing(recognizer);    //To change body of overridden methods use File | Settings | File Templates.
        }

        @Override
        public void onStopRecognizing(MRecognizer recognizer) {
            super.onStopRecognizing(recognizer);    //To change body of overridden methods use File | Settings | File Templates.
        }

        @Override
        public void onStartRecording(MRecognizer recognizer) {
            long time = System.currentTimeMillis();
            JoyPrint.e("record time",""+(time-startTime));
            super.onStartRecording(recognizer);    //To change body of overridden methods use File | Settings | File Templates.
        }

        @Override
        public void onStopRecording(MRecognizer recognizer) {
            super.onStopRecording(recognizer);    //To change body of overridden methods use File | Settings | File Templates.
        }
    };

    private EditText mResultEdit;
    private Button mStartButton;
    private MRecognizer mMRecognizer;
}
