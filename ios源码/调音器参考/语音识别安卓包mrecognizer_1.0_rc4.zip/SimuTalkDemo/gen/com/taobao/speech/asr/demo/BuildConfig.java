/*___Generated_by_IDEA___*/

/** Automatically generated file. DO NOT MODIFY */
package com.taobao.speech.asr.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}