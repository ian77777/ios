var NAVTREE_DATA =
[ [ "com.taobao.speech.asr", "com/taobao/speech/asr/package-summary.html", [ [ "Interfaces", null, [ [ "RecognizeListener", "com/taobao/speech/asr/RecognizeListener.html", null, "" ] ]
, "" ], [ "Classes", null, [ [ "MRecognizer", "com/taobao/speech/asr/MRecognizer.html", null, "" ], [ "MRecognizer.ErrorCode", "com/taobao/speech/asr/MRecognizer.ErrorCode.html", null, "" ], [ "RecognizeListener.RecognizedResult", "com/taobao/speech/asr/RecognizeListener.RecognizedResult.html", null, "" ], [ "StageListener", "com/taobao/speech/asr/StageListener.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

