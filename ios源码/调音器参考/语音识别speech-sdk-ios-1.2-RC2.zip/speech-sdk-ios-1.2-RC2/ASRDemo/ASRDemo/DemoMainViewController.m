//
//  DemoMainViewController.m
//  ASRDemo
//
//  Created by Shawn Chain on 13-11-13.
//  Copyright (c) 2013年 Alibaba MTeam. All rights reserved.
//

#import "DemoMainViewController.h"
#import "DemoViewController.h"
#import "TBASRViewController.h"
#import "LWASRViewController.h"

typedef enum {
    TBSearchTypeItem = 0,
	TBSearchTypeShop,
	TBSearchTypeTmall,
}TBSearchType;

@interface DemoMainViewController ()<TBASRDelegate>{
    SystemSoundID m_sound_src_id_pool[2];
}
@property (retain, nonatomic) IBOutlet UILabel *resultLabel;

@end

@implementation DemoMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    AudioServicesCreateSystemSoundID(
                                     (CFURLRef) [NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"asr_speak_now" ofType:@"wav"]],
                                     &(m_sound_src_id_pool[0]));
    
    AudioServicesCreateSystemSoundID(
                                     (CFURLRef) [NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"asr_cancel" ofType:@"wav"]],
                                     &(m_sound_src_id_pool[1]));
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)onStartRecognize:(id)sender{
    self.resultLabel.hidden=YES;
    DemoViewController *v = [[[DemoViewController alloc] initWithNibName:nil bundle:nil] autorelease];
    [self.navigationController pushViewController:v animated:YES];
}

- (IBAction)onStartTBRecognize:(id)sender {
    AudioServicesPlaySystemSound(m_sound_src_id_pool[0]);
    if([[[UIDevice currentDevice] systemVersion] floatValue]<5.0f){
        [self presentModalViewController:[[[TBASRViewController alloc] initWithDelegate:self :TBSearchTypeItem] autorelease] animated:YES];
    }else{
        [self presentViewController:[[[TBASRViewController alloc] initWithDelegate:self :TBSearchTypeItem] autorelease] animated:YES completion:nil];
    }
}

- (IBAction)onStartLWRecognize:(id)sender {
    [self presentModalViewController:[[[LWASRViewController alloc] init] autorelease] animated:YES];
}

- (int)searchWithASR:(NSString *) keywords :(int) searchType :(NSString *) category{
    self.resultLabel.hidden=NO;
    self.resultLabel.text=[NSString stringWithFormat:@"识别结果: %@",keywords];
    return 0;
}


- (void)dealloc {
    [_resultLabel release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setResultLabel:nil];
    [super viewDidUnload];
}
@end
