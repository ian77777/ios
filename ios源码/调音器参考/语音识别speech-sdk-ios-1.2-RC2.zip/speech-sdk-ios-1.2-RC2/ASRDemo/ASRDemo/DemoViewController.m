//
//  DemoViewController.m
//  ASRDemo
//
//  Created by Shawn Chain on 13-10-30.
//  Copyright (c) 2013年 MTeam. All rights reserved.
//

#import "DemoViewController.h"
#import <SpeechRecognizer/SpeechRecognizer.h>
#define SAFE_RELEASE(a) if(a){[a release];a=nil;}
@interface DemoViewController ()<MRecognizerDelegate>{
    BOOL bLogData;
}
@property(nonatomic,strong) IBOutlet UITextView *textView;
@property(nonatomic,strong) IBOutlet UIButton *button;
@property (nonatomic,strong) IBOutlet UIButton *saveButton;

@property(nonatomic,strong) MRecognizer *recognizer;
@end

@implementation DemoViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"语音识别";
    UIBarButtonItem *dismissButton = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(onDismiss:)] autorelease];
    self.navigationItem.rightBarButtonItem = dismissButton;
    
	// Do any additional setup after loading the view, typically from a nib.
    // check asr status
    self.button.enabled = [MRecognizer isServiceAvailable];
    
    // register for service status changes
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(asrStatusChanged:) name:kMRecognizerServiceStatusChanged object:nil];
    
    //利用指定的appKey来初始化MRecognizer，[[MRecognizer alloc] init]方法默认使用第一个appKey
    MRecognizer *r = [[[MRecognizer alloc] initWithAppkey:@"654321"] autorelease];
    r.mode=kMODE_RECORDER;
    r.delegate = self;
//    
    r.cancelOnAppEntersBackground = YES;
    r.enableUserCancelCallback = YES;
    self.recognizer = r;
    
    bLogData = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction)onStart:(id)sender{
    if([_recognizer isStarted]){
        // perform stop
        NSLog(@"button stop - %@", [NSDate date]);
        [self.button setTitle:@"Waiting" forState:UIControlStateNormal];
        self.button.enabled = NO;
        [_recognizer stop];
        self.saveButton.enabled=YES;
    }else{
        NSLog(@"button start - %@", [NSDate date]);
        [self.button setTitle:@"Waiting" forState:UIControlStateNormal];
        self.textView.text = @"Starting...";
        self.button.enabled = NO;
        self.saveButton.enabled=NO;
        [_recognizer start];
    }
}

-(IBAction)onCancel:(id)sender{
    [_recognizer cancel];
    self.textView.text = @"Canceled";
    
    [self.button setTitle:@"Start" forState:UIControlStateNormal];
    self.button.enabled = YES;
}

- (IBAction)onSave:(id)sender{
    if(bLogData){
        bLogData=NO;
        _recognizer.enableVoiceLog = NO;
        [self.saveButton setTitle:@"打开保存功能" forState:UIControlStateNormal];
    }else{
        bLogData=YES;
        _recognizer.enableVoiceLog = YES;
        [self.saveButton setTitle:@"关闭保存功能" forState:UIControlStateNormal];
    }
}

-(IBAction)onDismiss:(id)sender{
    [_recognizer cancel];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)dealloc{
    // stop listening to the notifications
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if([_recognizer isStarted]){
        _recognizer.delegate = nil;
        [_recognizer cancel];
    }
    self.recognizer = nil;
    
    SAFE_RELEASE(_textView);
    SAFE_RELEASE(_button);
    [_saveButton release];
    [super dealloc];
}

#pragma mark - notification callbacks
-(void)asrStatusChanged:(NSNotification*)notify{
    NSLog(@"ASR Status changed to: %@,%@",notify.object,notify.userInfo);
    self.button.enabled = [notify.object boolValue];
}

#pragma mark - RecognizeDelegate
-(void) recognizer:(MRecognizer*)recognizer didCompleteRecognizingWithResult:(MRecognizerResult*)result error:(NSError*)error{
    NSLog(@"!!! didCompleteRecognizingWithResult %@",result);
    if(error)
    {
        _textView.text = [NSString stringWithFormat:@"%@ code= %d\n%@",error.domain,error.code,error.userInfo];
    }else if(result){
        _textView.text = [NSString stringWithFormat:@"asr=%@\nnlp=%@\n",result.asrText, result.nlpIntents];
    }
    
    if(error){
        NSLog(@"Recognize Error: %@ - %@",error,error.userInfo);
    }
    
    //restore the button state;
    [self.button setTitle:@"Start" forState:UIControlStateNormal];
    self.button.enabled = YES;
}

-(void) recognizer:(MRecognizer*)recognizer recordingWithVoiceVolume:(NSUInteger)voiceVolume{
//    NSLog(@"Voice Volume %d",voiceVolume);
}

-(void) recognizerDidStartRecording:(MRecognizer*)recognizer{
    NSLog(@"!!! recognizerDidStartRecording - %@",[NSDate date]);
    self.textView.text = @"Please speak...";
    [self.button setTitle:@"Stop" forState:UIControlStateNormal];
    self.button.enabled = YES;
}
-(void) recognizerDidStopRecording:(MRecognizer*)recognizer{
    NSLog(@"!!! recognizerDidStopRecording - %@",[NSDate date]);
    self.textView.text = @"Recognizing...";    
}

-(void) recognizerDidStopRecording:(MRecognizer *)recognizer withRecorderData:(NSData *)data{
    NSLog(@"recorded: %d", [data length]);
    _textView.text = nil;
    [self.button setTitle:@"Start" forState:UIControlStateNormal];
    self.button.enabled = YES;
}

- (void)viewDidUnload {
    [self setSaveButton:nil];
    [super viewDidUnload];
}

@end
