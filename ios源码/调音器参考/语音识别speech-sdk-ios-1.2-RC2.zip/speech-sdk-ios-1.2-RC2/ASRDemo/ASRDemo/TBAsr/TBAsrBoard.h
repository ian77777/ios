//
//  LWAsrBoard.h
//  Laiwang
//
//  Created by dailin.dl on 13-10-10.
//  Copyright (c) 2013年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import "TBASREnv.h"


@protocol TBAsrBoardDelegate
//- (void) asrCleanMsg;
//- (void) asrSendMsg;
@required
- (void) asrMicClicked:(id) sender;
@end

typedef enum {
    TBASRNone = 0,
    TBASRRecording,
    TBASRLoading,
    TBASREnding
} TBASRAnimationStatus;

typedef enum {
    TBASRWAVETOP = 0,
    TBASRWAVEBOTTOM,
    TBASRWAVEUP,
    TBASRWAVEDOWN
} TBASRWAVEAnimationTYPE;

@interface TBAsrBoard : UIView
{
    int _status;
    int _asrWaveVolume;
    int _curAsrVolume;
    int _asrWaveCount;
    CGRect micRect;
    BOOL isRecordingAni;
}

//@property (nonatomic, strong) UIButton       *asrClearButton;
//@property (nonatomic, strong) UIButton       *asrSendButton;
@property (nonatomic, strong) UIImageView    *asrMicView;
@property (nonatomic, strong) UIButton       *asrMicBgView;
@property (nonatomic, strong) UIImageView    *asrLoadingView;
@property (nonatomic, strong) UIImageView    *asrWaveView;
@property (nonatomic, strong) UIImageView    *asrDefaultView;
@property (nonatomic, strong) UIImageView    *asrGroundView;
@property (nonatomic, strong) CALayer        *asrBgLayer;
@property (nonatomic, strong) CALayer        *asrWaveLayer;
@property (nonatomic, assign) id<TBAsrBoardDelegate>    delegate;


// by raymond
- (id)initLeView:(CGRect) frame :(id<TBAsrBoardDelegate>) ledelegate;



- (void)update:(int) value;
- (void)resetViewWithAnimation:(BOOL) animated;
- (void)startLoading;
- (void)endLoading;
- (void)startPreAnimation;
- (void)startRecording;
- (void)stopRecording;
//- (void)setButtonAvailable:(BOOL)type;
//- (void)playSound:(NSString *)name;
- (int)getStatus;

@end