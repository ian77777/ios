//
//  TBASRViewController.h
//  Taobao2013
//
//  Created by Raymond Yang on 29/10/13.
//  Copyright (c) 2013 Taobao.com. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <SpeechRecognizer/SpeechRecognizer.h>
#import <AudioToolbox/AudioToolbox.h>

#import "TBAsrBoard.h"
#import "TBASREnv.h"


@protocol TBASRDelegate
@required
- (int)searchWithASR:(NSString *) keywords :(int) searchType :(NSString *) category;
@end



@class SpeechRecognizer;
@class TBASRLabelView;
@class TBASRAnimationView;



@interface TBASRViewController : UIViewController <MRecognizerDelegate, TBAsrBoardDelegate> {
    CGRect m_thisvc_rect;
    float m_curr_floatversion;
    
    NSTimer *m_current_timer;
    
    
    
    // BULL SHIT
    // to avoid to start engine from background
    // since back from mic chk permission;
    BOOL m_is_resign_active_currently;
    BOOL m_is_become_active_from_mic_availability_chk;
    BOOL m_users_mic_availability_choice;
    
    
    
    // sound array
    SystemSoundID m_soundurlpool[TBASR_SOUNDEFFECT_FILE_NUMBER];
#ifdef ASR_IS_NO_ANIMATION
    UIButton *m_btnController;
#endif
}

/*
// engine 2.0
- (void)switchCurrStatus:(kTBASRStatus) lestatus;

- (BOOL)initEngine;
- (BOOL)flushEngine;

- (void)appWillResignActiveWithNotification:(NSNotification *) lenotification;
*/


// engine 1.0
- (id)initWithDelegate:(id<TBASRDelegate>) ledelegate :(int) lesearchtype;


- (void)btndismiss_ontapped:(id) sender;
- (void)searchJumpDelay:(NSTimer *) t;

//- (void)flushRecognizer;

- (void)tbasrModalWillResignActive:(NSNotification *) lenotification;
- (void)tbasrModalDidBecomeActive:(NSNotification *) lenotification;



// biz logic:

// init -> recording
- (void)startRecording:(NSTimer *) letimer;



// recording -> networking
- (void)pauseRecording:(NSTimer *) letimer;



// networking -> pending/errpending
- (void)haltNetworking:(NSTimer *) letimer;




@property (nonatomic, assign) kTBASRStatus p_currstatus;
@property (nonatomic, assign) int p_searchtype;

@property (nonatomic, strong) MRecognizer *p_recognizer;
@property (nonatomic, strong) id<TBASRDelegate> p_delegate;


@property (nonatomic, copy) NSString *p_keywords;


// uis
@property (nonatomic, strong) UIButton *p_btnquit;
@property (nonatomic, strong) TBASRLabelView *p_lblview;
@property (nonatomic, strong) TBAsrBoard *p_micview;


// sound id
@property (nonatomic, assign) SystemSoundID p_syssoundid_start;
@property (nonatomic, assign) SystemSoundID p_syssoundid_cancel;
@property (nonatomic, assign) SystemSoundID p_syssoundid_gotIt;
@property (nonatomic, assign) SystemSoundID p_syssoundid_success;
@property (nonatomic, assign) SystemSoundID p_syssoundid_error;

@end



////////////////////////////////////////
////////////////////////////////////////
////////////////////////////////////////



@interface TBASRLabelView : UIView

- (int)switchWithStatus:(kTBASRStatus) lestatus;


@property (nonatomic, assign) kTBASRStatus p_currstatus;
@property (nonatomic, strong) UILabel *p_lblTitleNotification;
@property (nonatomic, strong) UILabel *p_lblRest;
@property (nonatomic, strong) UILabel *p_lblNlp;

@end