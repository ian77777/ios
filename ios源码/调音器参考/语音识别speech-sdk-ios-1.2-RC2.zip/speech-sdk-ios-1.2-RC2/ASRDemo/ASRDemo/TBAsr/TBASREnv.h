//
//  TBASREnv.h
//  Taobao2013
//
//  Created by Raymond Yang on 29/10/13.
//  Copyright (c) 2013 Taobao.com. All rights reserved.
//

#ifndef Taobao2013_TBASREnv_h
#define Taobao2013_TBASREnv_h



/*
 
 DEBUG FLAG
 
 */

// NLP switcher
//#define ASR_NLP_ON YES


// no animation ui
//#define ASR_IS_NO_ANIMATION YES



#define ASR_ASRDAILY YES
#define ASR_MUTE_OFF YES


//#define ASR_DEBUG YES

#ifdef ASR_DEBUG

#define ASRTRACK NSLog(@"\n\nasr: %@ _ %@\n\n", NSStringFromClass([self class]), NSStringFromSelector(_cmd))
#define ASRDLOG(...) NSLog(@"\n\nasr: %@\n\n", [NSString stringWithFormat:__VA_ARGS__])

#else

#define ASRTRACK do{}while(0)
#define ASRDLOG(...) do{}while(0)

#endif



// animation tag

#define TBASR_ANIMATIONTAG_WAVE @"TBASR_ANIMATIONTAG_WAVE"
#define TBASR_ANIMATIONTAG_CURSORROTATION @"TBASR_ANIMATIONTAG_CURSORROTATION"
#define TBASR_ANIMATIONTAG_LOADINGROTATION @"TBASR_ANIMATIONTAG_LOADINGROTATION"



// wav file names

#define TBASR_WAVEFILENAME_ACCOMPLISHMENT @"asr_finished"
#define TBASR_WAVEFILENAME_CANCEL @"asr_cancel"
#define TBASR_WAVEFILENAME_ERROR @"asr_error"
#define TBASR_WAVEFILENAME_RECORDING @"asr_speak"
#define TBASR_WAVEFILENAME_SUCCESS @"asr_got_it"



// color ids

#define TBASR_ACTIVE_ORANGE [UIColor colorWithRed:1 green:91.0f/255.0 blue:0 alpha:1]
#define TBASR_DISABLE_GREY [UIColor colorWithRed:117.0f/255.0 green:117.0f/255.0 blue:132.0f/255.0 alpha:1]
#define TBASR_DISABLEMIC_GREY [UIColor colorWithRed:177.0f/255.0 green:185.0f/255.0 blue:195.0f/255.0 alpha:1]
//#define TBASR_STD_BGWHITE [UIColor colorWithRed:249.0f/255.0 green:249.0f/255.0 blue:249.0f/255.0 alpha:1]
#define TBASR_STD_BGWHITE [UIColor whiteColor]



/*
 <string name="asr_text0">亲，请大声说出\n您心仪的宝贝吧！</string>
 <string name="asr_text1">亲，未识别出您说话，\n请点击话筒重新开始！</string>
 <string name="asr_text3">亲，正在为您搜索...</string>
 <string name="asr_text4">亲，正在识别中...</string>
 <string name="asr_text5">亲，网络可能不通畅，\n请先检查您的网络后重试！</string>
 <string name="asr_text6">亲，服务正忙或者出错，\n请您稍候重试！</string> */

// asr std txt

#define TBASR_LBLTXT_WELCOME @"亲, 大声说出心仪的宝贝吧"
#define TBASR_LBLTXT_NETWORKING @"亲，正在识别中..."
#define TBASR_LBLTXT_ERR_RECOG @"亲, 未识别出您说话.\n请点击话筒重新开始!"
#define TBASR_LBLTXT_ERR_TOOSHORT @"亲，您点击过于频繁！"


// some extra lbls

#define TBASR_LBLTXT_ERR_NETWORK @"亲, 网络可能不通畅.\n请先检查您的网络后重试!"
#define TBASR_LBLTXT_ERR_SRV @"亲, 服务正忙或者出错.\n请您稍候重试!"
#define TBASR_LBLTXT_ERR_DOWNGRADE @"服务经已被降级"


#define TBASR_LBLTXT_SEARCHINGHEADER @"亲, 正在为您搜索"
#define TBASR_LBLTXT_MIC_IS_NOT_AVAILABLE @"亲, 无法录音!\n请到“设置-隐私-麦克风”选项中设置允许使用麦克风."



// asr volumn control

#define TBASR_MAX_WAVE_LEVEL 4
#define TBASR_MAX_WAVE_VALUE 100



// ALL ABOUT ANIMATION

#define TBASR_ANIMATION_FPS 30
#define TBASR_VOLUMN_UPDATING_ANIMATION_FPS 10

#define TBASR_ANIMATION_CIRCLE_STEP_RADIAN .09f


// engine property

#define TBASR_ENGINE_MIN_VAD_TIMEINTERVAL 1.2


// enums

typedef enum {
    kTBASRRecogStatus_Success,
    kTBASRRecogStatus_NothingRecognized,
    kTBASRRecogStatus_SrvErr,
    kTBASRRecogStatus_NetworkErr,
    kTBASRRecogStatus_UserCancel,
    kTBASRRecogStatus_Timeout,
    kTBASRRecogStatus_Tooshort,
    kTBASRRecogStatus_MicDisable,
    kTBASRRecogStatus_IllegalErrDomain,
    
    kTBASRRecogStatus_2G,
    kTBASRRecogStatus_3G,
    kTBASRRecogStatus_EDGE,
    kTBASRRecogStatus_HSPA,
    kTBASRRecogStatus_LTE,
    kTBASRRecogStatus_WIFI,
    kTBASRRecogStatus_UnknownErr
} kTBASRRecogStatus;



typedef enum {
    kTBASRSoundId_Start=0,
    kTBASRSoundId_GotIt=1, // recog ok
    kTBASRSoundId_Err=2,
    kTBASRSoundId_Cancel=3,
    kTBASRSoundId_Success=4 // jump to search compose view controller
} kTBASRSoundId;

#define TBASR_SOUNDEFFECT_FILE_NUMBER 5



typedef enum {
    
    kTBASRStatus_Next=0x00,
    kTBASRStatus_Frozen,
    kTBASRStatus_Pending,
    kTBASRStatus_ErrPending,
    kTBASRStatus_Recording,
    kTBASRStatus_Networking,
    kTBASRStatus_MicForbidden,
    kTBASRStatus_TargetSimulator
    
} kTBASRStatus;


#endif