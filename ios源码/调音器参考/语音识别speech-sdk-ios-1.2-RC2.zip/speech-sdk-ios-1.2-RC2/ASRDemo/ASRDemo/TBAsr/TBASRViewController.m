//
//  TBASRViewController.m
//  Taobao2013
//
//  Created by Raymond Yang on 29/10/13.
//  Copyright (c) 2013 Taobao.com. All rights reserved.
//

#import "TBASRViewController.h"
#import <AVFoundation/AVFoundation.h>


////////////////////////////////////////
////////////////////////////////////////
////////////////////////////////////////
#pragma mark - lbl view -



@implementation TBASRLabelView

@synthesize p_currstatus,
p_lblNlp,
p_lblRest,
p_lblTitleNotification;


- (id)initWithFrame:(CGRect)frame {
    self=[super initWithFrame:frame];
    if (self) {
        
        self.p_lblTitleNotification=[[UILabel alloc] initWithFrame:CGRectMake(20.0, 0, frame.size.width-40.0, 160.0)];
        
        self.p_lblTitleNotification.font=[UIFont systemFontOfSize:23.0];
        self.p_lblTitleNotification.textAlignment=NSTextAlignmentCenter;
        self.p_lblTitleNotification.textColor=TBASR_DISABLE_GREY;//[UIColor blackColor];
        self.p_lblTitleNotification.backgroundColor=[UIColor clearColor];
        self.p_lblTitleNotification.numberOfLines=3;
        
        
        self.p_lblRest=[[UILabel alloc] initWithFrame:CGRectMake(20.0, 20.0f, frame.size.width-40.0, 120.0)];
        
        self.p_lblRest.font=[UIFont systemFontOfSize:22.0];
        self.p_lblRest.textAlignment=NSTextAlignmentCenter;
        self.p_lblRest.textColor=TBASR_ACTIVE_ORANGE;
        self.p_lblRest.backgroundColor=[UIColor clearColor];
        self.p_lblRest.numberOfLines=3;

        self.p_lblNlp=[[UILabel alloc] initWithFrame:CGRectMake(20.0,
                                                                120,
                                                                frame.size.width-40.0,
                                                                100.0)];
        
        self.p_lblNlp.font=[UIFont systemFontOfSize:18.0];
        self.p_lblNlp.textAlignment=NSTextAlignmentCenter;
        self.p_lblNlp.textColor=TBASR_DISABLE_GREY;
        self.p_lblNlp.backgroundColor=[UIColor clearColor];
        self.p_lblNlp.numberOfLines=4;
        

        
        self.p_lblTitleNotification.hidden=NO;
        self.p_lblRest.hidden=YES;
        self.p_lblNlp.hidden=YES;
        
        [self addSubview:self.p_lblNlp];
        [self addSubview:self.p_lblRest];
        [self addSubview:self.p_lblTitleNotification];
    }
    return self;
}



- (int)switchWithStatus:(kTBASRStatus) lestatus; {
    self.p_currstatus=lestatus;
    
    switch (lestatus) {
        case kTBASRStatus_ErrPending: {
            
            self.p_lblNlp.hidden=self.p_lblRest.hidden=YES;
            // txt content will be settled down in callback
//            self.p_lblTitleNotification.text=TBASR_LBLTXT_ERR1;
            self.p_lblTitleNotification.hidden=NO;
            
            break;
        }
            
            
        case kTBASRStatus_Pending: {
            
            self.p_lblNlp.hidden=self.p_lblRest.hidden=YES;
            self.p_lblTitleNotification.text=TBASR_LBLTXT_WELCOME;
            self.p_lblTitleNotification.hidden=NO;
            
            break;
        }
            
        case kTBASRStatus_Networking: {
            
            self.p_lblNlp.hidden=self.p_lblRest.hidden=YES;
            self.p_lblTitleNotification.text=TBASR_LBLTXT_NETWORKING;
            
            self.p_lblTitleNotification.hidden=NO;
            
            break;
        }
            
        case kTBASRStatus_Recording: {
            
            self.p_lblNlp.hidden=self.p_lblRest.hidden=YES;
            self.p_lblTitleNotification.text=TBASR_LBLTXT_WELCOME;
            self.p_lblTitleNotification.hidden=NO;
            
            break;
        }
            
        case kTBASRStatus_MicForbidden: {
            
            self.p_lblNlp.hidden=self.p_lblRest.hidden=YES;
            self.p_lblTitleNotification.text=TBASR_LBLTXT_MIC_IS_NOT_AVAILABLE;
            self.p_lblTitleNotification.hidden=NO;
            
        }
            
            
        default: break;
    }
    
    return 0;
}

@end



////////////////////////////////////////
////////////////////////////////////////
////////////////////////////////////////



@implementation TBASRViewController
{
    UIView      *_maskView;
}

@synthesize p_recognizer,
p_micview,
p_btnquit,
p_currstatus,
p_delegate,
p_keywords,
p_lblview,
p_searchtype,
p_syssoundid_cancel,
p_syssoundid_error,
p_syssoundid_gotIt,
p_syssoundid_start,
p_syssoundid_success;



#pragma mark - lifecycle
- (void)dealloc {
    ASRTRACK;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self.p_micview resetViewWithAnimation:NO];
    
    if (self.p_recognizer!=nil) {
        self.p_delegate=nil;
        [self.p_recognizer cancel];
        self.p_recognizer=nil;
    }
    
    
    self.p_keywords=nil;
    self.p_btnquit=nil;
    self.p_delegate=nil;
    
    self.p_lblview=nil;
    self.p_micview=nil;
    
    // uninstall sound
    
#ifdef ASR_MUTE_OFF
    for (int idx=0; idx<TBASR_SOUNDEFFECT_FILE_NUMBER; idx++) {
        ASRDLOG(@"remove sound src id: %ld", m_soundurlpool[idx]);
//        AudioServicesRemoveSystemSoundCompletion(m_soundurlpool[idx]);
        AudioServicesDisposeSystemSoundID(m_soundurlpool[idx]);
    }
#endif
}

- (id)initWithDelegate:(id<TBASRDelegate>) ledelegate :(int) lesearchtype {
    printf("\n\n taobao A S R\n welcome\n\n\n");
    
    self=[super init];
    if (self) {
        self.p_delegate=ledelegate;
        self.p_searchtype=lesearchtype;
        
        
        ASRDLOG(@"\n\n\n current search type: %d\n\n\n", lesearchtype);
        
        
        // init env
        m_current_timer=nil;
        self.p_currstatus=kTBASRStatus_Frozen;
        
        
        // init engine
        self.p_recognizer=[[MRecognizer alloc] init];
        
        [self.p_recognizer setVadAutoStopTimeInterval:TBASR_ENGINE_MIN_VAD_TIMEINTERVAL];
        
        self.p_recognizer.cancelOnAppEntersBackground=YES;
        self.p_recognizer.enableUserCancelCallback=NO;
        
        
        m_is_resign_active_currently=NO;
        m_is_become_active_from_mic_availability_chk=NO;
        m_users_mic_availability_choice=YES;
        
        
        
#ifdef ASR_MUTE_OFF
        // prepare sound effect pool
        NSString *__sound_effect_src_name=nil;
        for (int idx=0; idx<TBASR_SOUNDEFFECT_FILE_NUMBER; idx++) {
            switch (idx) {
                case kTBASRSoundId_Success: {
                    __sound_effect_src_name=@"asr_got_it";
                    break;
                }
                    
                case kTBASRSoundId_GotIt: {
                    __sound_effect_src_name=@"asr_finished";
                    break;
                }
                    
                case kTBASRSoundId_Start: {
                    __sound_effect_src_name=@"asr_speak_now";
                    break;
                }
                    
                case kTBASRSoundId_Cancel: {
                    __sound_effect_src_name=@"asr_cancel";
                    break;
                }
                    
                case kTBASRSoundId_Err: {
                    __sound_effect_src_name=@"asr_error";
                    break;
                }
                    
                default:
                    break;
            }
            
            if (__sound_effect_src_name) {
                AudioServicesCreateSystemSoundID(
                                                 (__bridge CFURLRef) [NSURL URLWithString:[[NSBundle mainBundle] pathForResource:__sound_effect_src_name ofType:@"wav"]],
                                                 &(m_soundurlpool[idx]));
                ASRDLOG(@"alloc sound src id: %ld", m_soundurlpool[idx]);
                
                /*
                AudioServicesAddSystemSoundCompletion(m_soundurlpool[idx],
                                                      CFRunLoopGetCurrent(),
                                                      kCFRunLoopDefaultMode,
                                                      systemSoundDidFinished,
                                                      NULL); */
            }
        }
        __sound_effect_src_name=nil;
        /*
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
        UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
        AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute,
                                sizeof(audioRouteOverride),
                                &audioRouteOverride); */
#endif
        
        
        // add resign notification listener
        if ([self respondsToSelector:@selector(tbasrModalWillResignActive:)]) {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tbasrModalWillResignActive:) name:UIApplicationWillResignActiveNotification object:nil];
        }
        if ([self respondsToSelector:@selector(tbasrModalDidBecomeActive:)]) {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tbasrModalDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        }
    }
    return self;
}

- (void)loadView {
    ASRTRACK;
    m_curr_floatversion=[[[UIDevice currentDevice] systemVersion] floatValue];
    
    
    if (m_curr_floatversion<7.0f) {
        m_thisvc_rect=[[UIScreen mainScreen] applicationFrame];
    }
    else {
        m_thisvc_rect=[[UIScreen mainScreen] bounds];
    }
    
    
    self.view=[[UIView alloc] initWithFrame:m_thisvc_rect];
    self.view.backgroundColor=TBASR_STD_BGWHITE;
    self.view.clipsToBounds=YES;
    

    
    // quit btn
    self.p_btnquit=[UIButton buttonWithType:UIButtonTypeCustom];
    
    self.p_btnquit.frame=CGRectMake(0, 0, 60.0, 60.0);
    self.p_btnquit.backgroundColor=[UIColor clearColor];
    
    self.p_btnquit.userInteractionEnabled=NO;
    
    [self.p_btnquit setImage:[UIImage imageNamed:@"asr_quit.png"] forState:UIControlStateNormal];
    [self.p_btnquit setImage:[UIImage imageNamed:@"asr_quit.png"] forState:UIControlStateHighlighted];
    
    self.p_btnquit.showsTouchWhenHighlighted=YES;
    self.p_btnquit.center=CGPointMake(self.view.bounds.size.width-60*.5f,
                                        self.view.bounds.size.height-60*.5f);
    
    [self.p_btnquit addTarget:self action:@selector(btndismiss_ontapped:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    // lbl view
    
    
    self.p_lblview=[[TBASRLabelView alloc] initWithFrame:CGRectMake(0, 0, m_thisvc_rect.size.width, m_thisvc_rect.size.height-(80+222)*.5f-30*.5f)];
    self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_WELCOME;
    
    
    // init with welcome txt view
    // when this modal has been popped:
    
//    [self.p_lblview switchWithStatus:kTBASRStatus_Recording];
    
    [self.view addSubview:self.p_lblview];
    
    
#ifdef ASR_IS_NO_ANIMATION
    self.p_animationview=nil;
    m_btnController=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    m_btnController.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.3f];
    m_btnController.frame=CGRectMake(0, 0, 160, 120);
    [m_btnController setTitle:@"等待开始录音" forState:UIControlStateNormal];
    m_btnController.center=CGPointMake(m_thisvc_rect.size.width*.5f, m_thisvc_rect.size.height*.8f);
    [m_btnController addTarget:self action:@selector(btnController_ontapped:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:m_btnController];
#else
    
    
    self.p_micview=[[TBAsrBoard alloc] initLeView:CGRectMake(
m_thisvc_rect.size.width*.5f-220.0*.25f,
m_thisvc_rect.size.height-80*.5f-222.0*.5f, 220*.5f, 222*.5f)
                                                 :self];
    
    self.p_micview.asrMicBgView.userInteractionEnabled=YES;
    [self.view addSubview:self.p_micview];
    
#endif
    
    [self.view addSubview:self.p_btnquit];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    ASRTRACK;
    self.p_btnquit.userInteractionEnabled=YES;
    
    [UIView animateWithDuration:0.2 animations:^{
        _maskView.alpha = 0.0f;
    } completion:^(BOOL finished) {
        if([self.view.subviews containsObject:_maskView])
            [_maskView removeFromSuperview];
        
    }];
    
    if (m_curr_floatversion>6.99f && [[AVAudioSession sharedInstance] respondsToSelector:@selector(requestRecordPermission:)]) {
        
        [[AVAudioSession sharedInstance] performSelector:@selector(requestRecordPermission:) withObject:^(BOOL isMicAvailable) {
            
            m_users_mic_availability_choice=isMicAvailable;
            
            if (m_is_resign_active_currently) {
                m_is_become_active_from_mic_availability_chk=YES;
                return;
            }
            else if (isMicAvailable) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    ASRDLOG(@"mic is available...");
                    
                    [self startRecording:nil];
                    
                });
            }
            else {
                dispatch_async(dispatch_get_main_queue(), ^(void) {
                    ASRDLOG(@"mic is unavailable...");
                    
                    [self.p_lblview switchWithStatus:kTBASRStatus_MicForbidden];
                    
                });
            }// end of mic available chk
        }]; // end of mic chk block
        
    }
    else {
        ASRDLOG(@"start to record directly...");
        [self startRecording:nil];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    NSLog(@"\n\n%s\n\n", __FUNCTION__);
    
    self.p_recognizer.delegate=nil;
    [self.p_recognizer cancel];
    self.p_recognizer=nil;
    
    self.p_currstatus=kTBASRStatus_ErrPending;
    [self.p_lblview switchWithStatus:kTBASRStatus_ErrPending];
    self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_RECOG;
    
    [self.p_micview resetViewWithAnimation:NO];
    
    self.p_micview.asrMicBgView.userInteractionEnabled=YES;
}

- (void)tbasrModalWillResignActive:(NSNotification *) lenotification; {
    ASRTRACK;
    
    // status will change to pending
    m_is_resign_active_currently=YES;
    
    if (m_current_timer!=nil) {
        [m_current_timer invalidate];
        m_current_timer=nil;
        self.p_btnquit.userInteractionEnabled=YES;
    }
    
    if (self.p_recognizer!=nil) {
        self.p_recognizer.delegate=nil;
        //[self.p_recognizer cancel];
    }
}

- (void)tbasrModalDidBecomeActive:(NSNotification *) lenotification; {
    ASRTRACK;
    
    m_is_resign_active_currently=NO;
    
    
    // free the ui interactions
    
    self.p_micview.asrMicBgView.userInteractionEnabled=YES;
    self.p_micview.asrMicBgView.userInteractionEnabled=YES;
    
    if (!m_users_mic_availability_choice) {
        [self.p_lblview switchWithStatus:kTBASRStatus_MicForbidden];
        
        return;
    }
    else if (m_is_become_active_from_mic_availability_chk) {
        m_is_become_active_from_mic_availability_chk=NO;
        [self startRecording:nil];
        
        return;
    }
    else {
        self.p_currstatus=kTBASRStatus_ErrPending;
        [self.p_lblview switchWithStatus:kTBASRStatus_ErrPending];
        self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_RECOG;
        
        [self.p_micview resetViewWithAnimation:NO];
        
        return;
    }
}

#pragma mark - biz logic
- (void)btndismiss_ontapped:(id) sender; {
    ASRTRACK;
    
    if (self.p_recognizer!=nil) {
        self.p_recognizer.delegate=nil;
        [self.p_recognizer cancel];
    }
    
    
    self.p_btnquit.userInteractionEnabled=NO;
    
#ifdef ASR_MUTE_OFF
    AudioServicesPlaySystemSound(m_soundurlpool[kTBASRSoundId_Cancel]);
#endif
    
    m_current_timer=[NSTimer scheduledTimerWithTimeInterval:.3f target:self selector:@selector(dismissDelay:) userInfo:nil repeats:YES];
}

- (void)dismissDelay:(NSTimer *) letimer {
    ASRTRACK;
    if (letimer!=nil) {
        [letimer invalidate];
        m_current_timer=nil;
    }
    
    if (m_curr_floatversion<5.0f) {
        [self dismissModalViewControllerAnimated:YES];
    }
    else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
///////////////////////////////////
///////////////////////////////////
// init -> recording
- (void)startRecording:(NSTimer *) letimer; {
    ASRTRACK;
    
    if (letimer!=nil) {
        [letimer invalidate];
        m_current_timer=nil;
    }
    
    
    if (self.p_recognizer==nil) {
        self.p_recognizer=[[MRecognizer alloc] init];
        
        [self.p_recognizer setVadAutoStopTimeInterval:TBASR_ENGINE_MIN_VAD_TIMEINTERVAL];
        
        self.p_recognizer.cancelOnAppEntersBackground=YES;
        self.p_recognizer.enableUserCancelCallback=NO;
    }
    
    
    self.p_recognizer.delegate=self;
    
    
    
#ifdef ASR_IS_NO_ANIMATION
    [m_btnController setTitle:@"点击直接上传" forState:UIControlStateNormal];
    [m_btnController setTitle:@"点击直接上传" forState:UIControlStateHighlighted];
    m_btnController.userInteractionEnabled=YES;
#else
    
    [self.p_micview startRecording];
    
#endif
    
    [self.p_lblview switchWithStatus:kTBASRStatus_Recording];
    self.p_keywords=nil;
    
    
    ASRDLOG(@"start the engine...");
    [self.p_recognizer start];
}

// recording -> networking
- (void)pauseRecording:(NSTimer *) letimer; {
    if (letimer!=nil) {
        [letimer invalidate];
    }
    

#ifdef ASR_IS_NO_ANIMATION
    
    [m_btnController setTitle:@"点击中断识别" forState:UIControlStateNormal];
    [m_btnController setTitle:@"点击中断识别" forState:UIControlStateHighlighted];
    m_btnController.userInteractionEnabled=YES;
    
#else
    
    
    [self.p_micview stopRecording];
    [self.p_micview startLoading];
    
    
#endif
    [self.p_lblview switchWithStatus:kTBASRStatus_Networking];
}

// networking -> pending/errpending
- (void)haltNetworking:(NSTimer *) letimer; {
    if (letimer!=nil) {
        [letimer invalidate];
    }
    
    
#ifdef ASR_IS_NO_ANIMATION
    [m_btnController setTitle:@"点击开始录音" forState:UIControlStateNormal];
    [m_btnController setTitle:@"点击开始录音" forState:UIControlStateHighlighted];
    m_btnController.userInteractionEnabled=YES;
#endif
    
    [self.p_recognizer cancel];
}

- (void)searchJumpDelay:(NSTimer *) t; {
    ASRTRACK;
        
    if (self.p_lblview.p_lblNlp.hidden) {
        self.p_lblview.p_lblNlp.hidden=NO;
        return;
    }
    else if (t!=nil) {
        [t invalidate];
    }
    
#ifdef ASR_MUTE_OFF
    AudioServicesPlaySystemSound(m_soundurlpool[kTBASRSoundId_Success]);
#endif
    

    if (m_curr_floatversion<5.0) {
        [self.p_delegate searchWithASR:[NSString stringWithFormat:@"%@", self.p_keywords] :self.p_searchtype :nil];
        [self dismissModalViewControllerAnimated:YES];
    }
    else {
        [self dismissViewControllerAnimated:YES completion:^(void) {
            [self.p_delegate searchWithASR:[NSString stringWithFormat:@"%@", self.p_keywords] :self.p_searchtype :nil];
        }];
    }
}

#pragma mark - websocket engine callbacks: -
/**
 *@discussion 语音识别的关键回调函数，delegate必须实现。
 *
 *@param recognizer
 *@param result MRecognizerResult 返回值对象
 *@param error  NSError 识别错误和异常
 */
-(void) recognizer:(MRecognizer*)recognizer didCompleteRecognizingWithResult:(MRecognizerResult*)result error:(NSError*)error; {
    
    ASRTRACK;
    ASRDLOG(@"err: %@ recog result kind: %@",
            (error==nil)?@"none":[error.userInfo objectForKey:NSLocalizedDescriptionKey],
            NSStringFromClass([[result.nlpIntents objectAtIndex:0] class]));
    ASRDLOG(@"didCompleteRecognizing.errorcode=%d",error.code);
    
    /**
     * 错误域
     */
    /*
    extern NSString * const kMRecognizerErrorDomain; // NSError domain
    extern NSString * const kMRecognizerErrorServiceUnavailable; /// 语音服务不可用
    extern NSString * const kMRecognizerErrorNetworkUnavailable; /// 网络错误
    extern NSString * const kMRecognizerErrorUserCancelled;      /// 用户取消
    extern NSString * const kMRecognizerErrorNoMicAccess;   // 用户禁用了MIC
    extern NSString * const kMRecognizerErrorNotRecognized;   // 录音时间太短,或者服务器无法理解
     */
    
    
    BOOL _is_recog=NO;
    self.p_lblview.p_lblTitleNotification.hidden=YES;
    kTBASRRecogStatus flag;
    
//    NSString *__err_string=[error.userInfo objectForKey:NSLocalizedDescriptionKey];
    
    if (error!=nil) {
        if(error.code == kERR_SERVICE_ERROR){
            flag=kTBASRRecogStatus_SrvErr;
        }else if(error.code == kERR_NETWORK_ERROR){
            flag=kTBASRRecogStatus_NetworkErr;
        }else if(error.code == kERR_USER_CANCELED){
            flag=kTBASRRecogStatus_UserCancel;
        }else if(error.code == kERR_MIC_ERROR){
            flag=kTBASRRecogStatus_MicDisable;
        }else if(error.code == kERR_VOICE_ERROR){
            flag=kTBASRRecogStatus_NothingRecognized;
        }else if(error.code == kERR_TOOSHORT_ERROR){
            flag=kTBASRRecogStatus_Tooshort;
        }else{
            flag=kTBASRRecogStatus_UnknownErr;
        }
    }else {
        flag=kTBASRRecogStatus_Success;
    }
    
    switch (flag) {
        case kTBASRRecogStatus_Success: {
            ASRDLOG(@"return normal and parsing resp...");
            
            
            if (result.asrText==nil || [result.asrText length]<1) {
                _is_recog=YES;
            }
            else {
                self.p_keywords=[NSString stringWithFormat:@"%@", [result.asrText stringByReplacingOccurrencesOfString:@"。" withString:@""]];
                self.p_lblview.p_lblRest.text=[NSString stringWithFormat:@"“%@”", self.p_keywords];
                
                self.p_lblview.p_lblNlp.text=nil;
                if (result.nlpIntents!=nil
                    &&
                    [result.nlpIntents count]>0) {
                    
                    for (MRecognizerNLPIntent *leintent in result.nlpIntents) {
                        if([leintent isKindOfClass:[MRecognizerNLPSearchIntent class]]){
                            self.p_lblview.p_lblNlp.text=[NSString stringWithFormat:@"%@\n“%@”",
                                                          TBASR_LBLTXT_SEARCHINGHEADER,
                                                          ((MRecognizerNLPSearchIntent *) leintent).keywords];
                            self.p_keywords=((MRecognizerNLPSearchIntent *) leintent).keywords;
                            break;
                        }else if([leintent isKindOfClass:[MRecognizerNLPTicketIntent class]]){
                            self.p_keywords=[NSString stringWithFormat:@"从 %@ 到 %@ 的机票",((MRecognizerNLPTicketIntent *) leintent).departureCity,
                                ((MRecognizerNLPTicketIntent *) leintent).arrivalCity];
                            self.p_lblview.p_lblNlp.text=[NSString stringWithFormat:@"%@\n“%@”",
                                            TBASR_LBLTXT_SEARCHINGHEADER,
                                            self.p_keywords];
                            break;
                        }else if([leintent isKindOfClass:[MRecognizerNLPChargeIntent class]]){
                            self.p_keywords=[NSString stringWithFormat:@"为 %@ 充 %@",((MRecognizerNLPChargeIntent *) leintent).phonenum,
                                ((MRecognizerNLPChargeIntent *) leintent).amount];
                            self.p_lblview.p_lblNlp.text=[NSString stringWithFormat:@"%@\n“%@”",
                                                          @"正在",
                                                          self.p_keywords];
                        }else if([leintent isKindOfClass:[MRecognizerNLPLotteryIntent class]]){
                            self.p_keywords=[NSString stringWithFormat:@"买 %@ %@",((MRecognizerNLPLotteryIntent *) leintent).lotteryCount,
                                ((MRecognizerNLPLotteryIntent *) leintent).lotteryType];
                            self.p_lblview.p_lblNlp.text=[NSString stringWithFormat:@"%@\n“%@”",
                                                          @"正在",
                                                          self.p_keywords];
                        }
                    }// end of intent array loop
                    
                }// end of intent nil chk
                
                
                if (self.p_lblview.p_lblNlp.text==nil) {
                    self.p_lblview.p_lblNlp.text=[NSString stringWithFormat:@"%@\n“%@”",
                                                  TBASR_LBLTXT_SEARCHINGHEADER,
                                                  self.p_keywords];
                }
                self.p_lblview.p_lblRest.hidden=NO;
            } // resp string nil chk
            
            
            if (_is_recog || self.p_delegate==nil) {
                
                // this is parsing err
                
#ifdef ASR_MUTE_OFF
                AudioServicesPlaySystemSound(m_soundurlpool[kTBASRSoundId_Err]);
#endif
                
                [self.p_lblview switchWithStatus:kTBASRStatus_ErrPending];
                self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_RECOG;
                

                self.p_currstatus=kTBASRStatus_ErrPending;
                
                
#ifdef ASR_IS_NO_ANIMATION
                m_btnController.userInteractionEnabled=YES;
                [m_btnController setTitle:@"点击开始录音" forState:UIControlStateNormal];
                [m_btnController setTitle:@"点击开始录音" forState:UIControlStateHighlighted];
#else
                [self.p_micview endLoading];
#endif
            }
            else {
                
                
                // lock the uis
                
                self.p_currstatus=kTBASRStatus_Frozen;
                self.p_micview.asrMicBgView.userInteractionEnabled=NO;
                self.p_btnquit.userInteractionEnabled=NO;
                
                
#ifdef ASR_IS_NO_ANIMATION
                m_btnController.userInteractionEnabled=NO;
                [m_btnController setTitle:@"准备跳转" forState:UIControlStateNormal];
                [m_btnController setTitle:@"准备跳转" forState:UIControlStateHighlighted];
#else
                [self.p_micview endLoading];
#endif
#ifdef ASR_MUTE_OFF
                AudioServicesPlaySystemSound(m_soundurlpool[kTBASRSoundId_GotIt]);
#endif
                m_current_timer=[NSTimer scheduledTimerWithTimeInterval:1.2f target:self selector:@selector(searchJumpDelay:) userInfo:nil repeats:YES];
            }
            break;
        }
        default: {
#ifdef ASR_MUTE_OFF
            AudioServicesPlaySystemSound(m_soundurlpool[kTBASRSoundId_Err]);
#endif
            
            switch (flag) {
                case kTBASRRecogStatus_NetworkErr: {
                    self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_NETWORK;
                    break;
                }
                case kTBASRRecogStatus_SrvErr: {
                    self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_SRV;
                    break;
                }
                case kTBASRRecogStatus_Tooshort: {
                    self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_TOOSHORT;
                    break;
                }
                    
                default: {
                    self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_RECOG;
                    break;
                }
            }
            
            
            [self.p_lblview switchWithStatus:kTBASRStatus_ErrPending];
            self.p_currstatus=kTBASRStatus_ErrPending;
            
#ifdef ASR_IS_NO_ANIMATION
            m_btnController.userInteractionEnabled=YES;
            [m_btnController setTitle:@"点击开始录音" forState:UIControlStateNormal];
            [m_btnController setTitle:@"点击开始录音" forState:UIControlStateHighlighted];
#else
            [self.p_micview endLoading];
#endif
            break;
        }
    }  // end switch case
    return;
}

/**
 *@discussion 返回录音的语音PCM数据，调用频率取决于SDK内部设定。
 *@param recognizer
 *@param voiceData 语音PCM数据
 */
//-(void) recognizer:(MRecognizer*)recognizer recordingWithVoiceData:(NSData*)voiceData;

/**
 *@discussion 返回录音的语音音量，调用频率取决于SDK内部设定。
 *@param recognizer
 *@param voiceVolume 0-100的数值
 */
-(void) recognizer:(MRecognizer*)recognizer recordingWithVoiceVolume:(NSUInteger)voiceVolume; {
//    [self.p_animationview updateWave:[[NSNumber numberWithUnsignedInteger:voiceVolume] intValue]];
    
    [self.p_micview update:[[NSNumber numberWithUnsignedInteger:voiceVolume] intValue]];
}

/**
 *@discussion 开始录音的回调通知
 */
-(void) recognizerDidStartRecording:(MRecognizer*)recognizer; {
    ASRTRACK;
    self.p_currstatus=kTBASRStatus_Recording;
    // open for tapping
    
    [self.p_micview startPreAnimation];
}


/**
 *@discussion 停止录音的回调通知
 */
-(void) recognizerDidStopRecording:(MRecognizer*)recognizer; {
    ASRTRACK;
    [self pauseRecording:nil];
    self.p_currstatus=kTBASRStatus_Networking;
}

/**
 *@discussion 开始识别的回调通知
 */
-(void) recognizerDidStartRecognizing:(MRecognizer*)recognizer; {
    ASRTRACK;
    self.p_currstatus=kTBASRStatus_Networking;
}

/**
 *@discussion 识别结束的回调通知
 */
//-(void) recognizerDidStopRecognizing:(MRecognizer*)recognizer;


/**
 * @discussion 当远端服务状态发生变化的时候，该方法会自动被调用，返回服务状态变更。开发者可以根据测返回值，调整UI行为。
 *
 * @return service online的布尔值
 */
-(void) serviceStatusChanged:(BOOL)online; {
    return;
}


/*
#pragma mark - animation view delegate: -

- (int)aniamtionDidFinishWithStatus:(kTBASR_AnimationStatus) lestatus; {
    ASRTRACK;
    
    switch (lestatus) {
        case kTBASR_AnimationStatus_ExpandWave: {
            
            [self startRecording:nil];
            
            break;
        }
            
            
        case kTBASR_AnimationStatus_Pending: {
            
#ifndef ASR_IS_NO_ANIMATION
            self.p_animationview.p_micview.userInteractionEnabled=YES;
#endif
            
            break;
        }
            
            
        case kTBASR_AnimationStatus_Trans: {
            
            [self searchJumpDelay:nil];
            
            break;
        }
            
        default: break;
    }
    
    return 0;
}
*/



#pragma mark - laiwang animation callback: -

- (void)asrMicClicked:(id) sender; {
    switch (self.p_currstatus) {
        case kTBASRStatus_Recording: {
            ASRDLOG(@"%s switch from status: recording", __FUNCTION__);
            [self.p_recognizer stop];
            break;
        }
            
        case kTBASRStatus_Networking: {
            ASRDLOG(@"%s switch from status: networking", __FUNCTION__);
            
#ifdef ASR_MUTE_OFF
//            AudioServicesPlaySystemSound(kTBASRSoundId_Cancel);
#endif
            
            [self.p_recognizer cancel];
            
            
            [self.p_lblview switchWithStatus:kTBASRStatus_ErrPending];
            self.p_currstatus=kTBASRStatus_ErrPending;
            self.p_lblview.p_lblTitleNotification.text=TBASR_LBLTXT_ERR_RECOG;
            
            [self.p_micview resetViewWithAnimation:YES];
            
//            self.p_micview.asrMicBgView.userInteractionEnabled=YES;
            break;
        }
            
        case kTBASRStatus_ErrPending:
        case kTBASRStatus_Pending: {
            ASRDLOG(@"%s switch from status: err/pending", __FUNCTION__);
#ifdef ASR_MUTE_OFF
            AudioServicesPlaySystemSound(m_soundurlpool[kTBASRSoundId_Start]);
#endif
            
            // chk mic
            
            if (m_curr_floatversion>6.99f && [[AVAudioSession sharedInstance] respondsToSelector:@selector(requestRecordPermission:)]) {
                [[AVAudioSession sharedInstance] performSelector:@selector(requestRecordPermission:) withObject:^(BOOL isMicAvailable) {
                    if (isMicAvailable) {
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            ASRDLOG(@"mic is available...");
                            [self startRecording:nil];
                        });
                    }
                    else {
                        
                        dispatch_async(dispatch_get_main_queue(), ^(void) {
                            ASRDLOG(@"mic is forbidden...");
                            [self.p_lblview switchWithStatus:kTBASRStatus_MicForbidden];
                            self.p_currstatus=kTBASRStatus_MicForbidden;
                        });
                    }
                }];
            }
            else {
                ASRDLOG(@"start to record directly...");
                [self startRecording:nil];
            }
            break;
        }
            
            
        case kTBASRStatus_TargetSimulator: {
            
            self.p_keywords=@"阿迪达斯运动鞋";
            self.p_lblview.p_lblNlp.hidden=NO;
            [self searchJumpDelay:nil];
            
            break;
        }
            
            
        case kTBASRStatus_MicForbidden:
        case kTBASRStatus_Frozen:
        case kTBASRStatus_Next:
        default: {
            ASRDLOG(@"will response nothing");
            break;
        }
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if(_maskView == nil)
    {
        _maskView = [[UIView alloc] initWithFrame:self.view.bounds];
        _maskView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.8];
        _maskView.alpha = 0.8f;
    }
    
    if(![self.view.subviews containsObject:_maskView])
        [self.view addSubview:_maskView];
}

@end