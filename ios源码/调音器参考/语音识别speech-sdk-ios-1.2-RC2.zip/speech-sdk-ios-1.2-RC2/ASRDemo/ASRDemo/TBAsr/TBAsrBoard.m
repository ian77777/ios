//
//  TBAsrBoard.m
//  Laiwang
//
//  Created by dailin.dl on 13-10-10.
//  Copyright (c) 2013年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import "TBAsrBoard.h"
#import <QuartzCore/QuartzCore.h>

#define ASR_LOADING_ANIMATION @"asr_loading_animation"
#define ASR_WAVE_ANIMATION @"asr_wave_animation"

@implementation TBAsrBoard
//@synthesize asrClearButton = _asrClearButton;
//@synthesize asrSendButton = _asrSendButton;
@synthesize asrMicView = _asrMicView;
@synthesize asrMicBgView = _asrMicBgView;
@synthesize asrLoadingView = _asrLoadingView;
@synthesize asrWaveView = _asrWaveView;
@synthesize asrGroundView = _asrGroundView;
@synthesize asrBgLayer = _asrBgLayer;
@synthesize asrWaveLayer = _asrWaveLayer;


- (void)dealloc
{
    
    ASRTRACK;
    
    //    self.asrClearButton = nil;
    //    self.asrSendButton = nil;
    self.asrMicView = nil;
    self.asrLoadingView = nil;
    if (self.asrBgLayer)
    {
        [_asrBgLayer removeAllAnimations];
    }
    self.asrBgLayer = nil;
    
    if (self.asrWaveLayer)
    {
        [_asrWaveLayer removeAllAnimations];
    }
    self.asrWaveLayer = nil;
    
    self.asrMicBgView = nil;
    self.asrWaveView = nil;
    self.asrDefaultView = nil;
    self.asrGroundView = nil;
}


- (id)initLeView:(CGRect) frame :(id<TBAsrBoardDelegate>) ledelegate; {
    self=[super initWithFrame:frame];
    if (self) {
        self.delegate=ledelegate;
        [self initComponent:frame];
    }
    return self;
}



- (void)initComponent:(CGRect) frame
{
    _asrGroundView = [[UIImageView alloc] initWithFrame: CGRectMake(0, 0,
                                                                    self.bounds.size.width,
                                                                    self.bounds.size.height)];
    
    [_asrGroundView setImage:[UIImage imageNamed:@"asr_ground.png"]];
    
    
    
    /*
     _asrClearButton = [[UIButton alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.frame) - 41 , CGRectGetWidth(self.frame) / 2, 41)];
     [_asrClearButton addTarget:self action:@selector(asrClearClicked) forControlEvents:UIControlEventTouchDown];
     [_asrClearButton setTitle:@"清空" forState:UIControlStateNormal];
     [_asrClearButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
     [_asrClearButton setBackgroundImage:[UIImage imageNamed:@"asr_clean_button.png"] forState:UIControlStateNormal];
     
     _asrSendButton = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetWidth(self.frame) / 2, CGRectGetHeight(self.frame) - 41 , CGRectGetWidth(self.frame) / 2, 41)];
     [_asrSendButton addTarget:self action:@selector(asrSendClicked) forControlEvents:UIControlEventTouchDown];
     [_asrSendButton setTitle:@"发送" forState:UIControlStateNormal];
     [_asrSendButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
     [_asrSendButton setBackgroundImage:[UIImage imageNamed:@"asr_send_button.png"] forState:UIControlStateNormal]; */
    
    
    _asrMicBgView=[UIButton buttonWithType:UIButtonTypeCustom];
    _asrMicBgView.frame=CGRectMake(
                                   frame.size.width*.5f - 220*.25f,
                                   frame.size.height*.5f-222*.25f, 220*.5f, 222*.5f);
    
    _asrMicBgView.backgroundColor=[UIColor clearColor];
    
    [_asrMicBgView addTarget:self action:@selector(asrMicClicked:) forControlEvents:UIControlEventTouchDown];
    
    self.asrBgLayer = [CALayer layer];
    _asrBgLayer.contentsScale = [[UIScreen mainScreen] scale];
    _asrBgLayer.contentsGravity=kCAGravityCenter;
    _asrBgLayer.frame = CGRectMake(0, 0 , 110, 111);
    _asrBgLayer.contents=(id) [[UIImage imageNamed:@"asr_round_dark.png"] CGImage];
    [_asrMicBgView.layer addSublayer:_asrBgLayer];
    _asrMicBgView.userInteractionEnabled = YES;
    
    _asrLoadingView = [[UIImageView alloc] initWithFrame: CGRectMake(
                                                                     frame.size.width*.5f - 220*.25f,
                                                                     frame.size.height*.5f-220*.25f, 220*.5f, 220*.5f)];
    
    [_asrLoadingView setImage:[UIImage imageNamed:@"asr_loading.png"]];
    _asrLoadingView.alpha = 0;
    
    
    _asrWaveView = [[UIImageView alloc] initWithFrame:
                    CGRectMake(frame.size.width*.5f-15*.5f,
                               frame.size.height*.5f-6.0, 42.0, 33.0)];
    
    micRect = _asrWaveView.frame;
    
    
    
    self.asrWaveLayer = [CALayer layer];
    _asrWaveLayer.contentsScale = [[UIScreen mainScreen] scale];
    _asrWaveLayer.contentsGravity=kCAGravityCenter;
    _asrWaveLayer.frame = CGRectMake(0, 0 , 42.0, 33.0);
    _asrWaveLayer.contents=(id) [[UIImage imageNamed:@"asr_wave.png"] CGImage];
    [_asrWaveView.layer addSublayer:_asrWaveLayer];
    
    _asrDefaultView = [[UIImageView alloc] initWithFrame:
                       CGRectMake(frame.size.width*.5f-16*.5f,
                                  frame.size.height*.5f - 21.5f , 16, 29)];
    [_asrDefaultView setImage:[UIImage imageNamed:@"asr_mask.png"]];
    
    
    /*
     UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(asrMicClicked:)];
     [_asrMicBgView addGestureRecognizer:singleTap];*/
    
    
    _asrWaveVolume = 0;
    _status=TBASRNone;
    
    [self addSubview:_asrGroundView];
    //    [self addSubview:_asrClearButton];
    //    [self addSubview:_asrSendButton];
    
    [self addSubview:_asrDefaultView];
    // wave should here
    [self addSubview:_asrWaveView];
    
    
    [self addSubview:_asrMicBgView];
    
    [self addSubview:_asrLoadingView];
    
    
    //     [self addSubview:_asrWaveView];
}

- (void)asrMicClicked:(id) sender
{
    if(self.delegate) {
        [self.delegate asrMicClicked:sender];
    }
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */



// deprecated
/*
 - (void) asrClearClicked
 {
 if(self.delegate)
 [self.delegate asrCleanMsg];
 
 [self setButtonAvailable:false];
 }
 */

// deprecated
/*
 -(void) asrSendClicked
 {
 if(self.delegate)
 [self.delegate asrSendMsg];
 
 [self setButtonAvailable:false];
 }
 */


// 更新音量状态
-(void) update:(int)value
{
    _curAsrVolume = value;
}


// deprecated

/*
 -(void) setButtonAvailable:(BOOL)type
 {
 if (type)
 {
 [_asrClearButton setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
 _asrClearButton.enabled = true;
 [_asrSendButton setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
 _asrSendButton.enabled = true;
 
 }
 else
 {
 [_asrClearButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
 _asrClearButton.enabled = false;
 [_asrSendButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
 _asrSendButton.enabled = false;
 }
 } */



// 开始渐变动画
- (void)startPreAnimation
{
    _status = TBASRRecording;
    _asrWaveCount = 0;
    [CATransaction begin];
    [CATransaction setAnimationDuration:.63f];
    [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
    [CATransaction setCompletionBlock:nil];
    _asrBgLayer.contents=(id) [[UIImage imageNamed:@"asr_round.png"] CGImage];
    [CATransaction commit];
    //    [_asrMicBgView setImage:[UIImage imageNamed:@"asr_round.png"]];
    
    //    [_asrMicBgView setBackgroundImage:[UIImage imageNamed:@"asr_round.png"] forState:UIControlStateNormal];
    _asrWaveVolume = 0;
    _asrLoadingView.alpha = 0;
    
    CABasicAnimation *_ra = [CABasicAnimation animationWithKeyPath:@"position.x"];
    _ra.duration = 0.63f;
    _ra.repeatCount = HUGE_VAL;
    _ra.autoreverses = NO;
    _ra.fromValue = [NSNumber numberWithFloat:-6.0f];
    _ra.toValue = [NSNumber numberWithFloat:15.0f];
    _ra.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    [_asrWaveLayer addAnimation:_ra forKey:ASR_WAVE_ANIMATION];
    
    if (!isRecordingAni)
    {
        [self startWaveAnimation:TBASRWAVETOP];
    }
}

-(void) startRecording
{
}

-(void) stopRecording
{
}

-(void) startLoading
{
    _status = TBASRLoading;
    [self startLoadingAnimation];
    _asrLoadingView.alpha = 1.0f;
}

-(void) endLoading
{
    _status = TBASREnding;
    [self resetViewWithAnimation:YES];
}


// 结束渐变动画
- (void)resetViewWithAnimation:(BOOL) animated;
{
    _status = TBASREnding;
    
    
    if (animated) {
        [UIView animateWithDuration:0.5f delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
            _asrLoadingView.alpha = 0;
        } completion:^(BOOL finished) {
            //        printf("resetView\n");
            _asrLoadingView.alpha = 0;
            
            if (_status == TBASREnding)
            {
                _status = TBASRNone;
                [_asrLoadingView.layer removeAllAnimations];
                [_asrWaveLayer removeAllAnimations];
            }
        }];
        
        [CATransaction begin];
        [CATransaction setAnimationDuration:.5f];
        [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
        [CATransaction setCompletionBlock:nil];
        _asrBgLayer.contents=(id) [[UIImage imageNamed:@"asr_round_dark.png"] CGImage];
        [CATransaction commit];
    }
    else {
        
        _asrLoadingView.alpha=0;
        if (_status == TBASREnding)
        {
            _status = TBASRNone;
            [_asrLoadingView.layer removeAllAnimations];
            [_asrWaveLayer removeAllAnimations];
        }
        
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        _asrBgLayer.contents=(id) [[UIImage imageNamed:@"asr_round_dark.png"] CGImage];
        [CATransaction commit];
    }
    
    
    //    [self setButtonAvailable:true];
}


// 计算水波纹高度
- (CGRect)calcWaveHeight:(CGRect) rect
{
    //    if (_curAsrVolume > _asrWaveVolume + 5)
    //    {
    //        if (_asrWaveCount >= 2)
    //        {
    //            _asrWaveVolume = _asrWaveVolume + 5;
    //            _asrWaveCount = 0;
    //        }
    //        else
    //        {
    //            _asrWaveCount++;
    //        }
    //    }
    //    else if (_curAsrVolume < _asrWaveVolume - 10)
    //    {
    //        if (_asrWaveCount >= 1)
    //        {
    //            _asrWaveVolume = _asrWaveVolume - 10;
    //            _asrWaveCount = 0;
    //        }
    //        else
    //        {
    //            _asrWaveCount++;
    //        }
    //    }
    //    else if (_curAsrVolume < _asrWaveVolume - 5)
    //    {
    //        if (_asrWaveCount >= 1)
    //        {
    //            _asrWaveVolume = _asrWaveVolume - 5;
    //            _asrWaveCount = 0;
    //        }
    //        else
    //        {
    //            _asrWaveCount++;
    //        }
    //    }
    
    _asrWaveVolume = _curAsrVolume;
    if (_asrWaveVolume <= 45) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f+2;
    }else if (_asrWaveVolume <= 50) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f;
    }else if (_asrWaveVolume <= 55) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f-4;
    }else if (_asrWaveVolume <= 60) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 6;
    }else if (_asrWaveVolume <= 65) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 8;
    }else if (_asrWaveVolume <= 70) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 10;
    }else if (_asrWaveVolume <= 72) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 12;
    }else if (_asrWaveVolume <= 74) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 14;
    }else if (_asrWaveVolume <= 76) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 16;
    }else if (_asrWaveVolume <= 78) {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 18;
    }else
    {
        rect.origin.y = CGRectGetHeight(self.frame)*.5f - 20;
    }
    
    return rect;
}


// 水纹垂直移动动画
- (void)startWaveAnimation:(TBASRWAVEAnimationTYPE)type
{
    //    [UIView animateWithDuration:0.1f delay:0
    //                        options:UIViewAnimationOptionCurveLinear
    //                     animations:^{
    //                           _asrWaveView.frame = [self calcWaveHeight:_asrWaveView.frame];
    //                     } completion:^(BOOL finished) {
    //                         if (_status == TBASRRecording || _status == TBASRLoading)
    //                         {
    //                             [self startWaveAnimation];
    //                         }
    //                     }];
    isRecordingAni = TRUE;
    if (type == TBASRWAVETOP)
    {
        [UIView animateWithDuration:0.2f delay:0
                            options:UIViewAnimationOptionAllowUserInteraction
                         animations:^{
                             CGRect rect;
                             
                             rect = micRect;
                             rect.origin.y = CGRectGetHeight(self.frame)*.5f - 23.0;
                             
                             
                             _asrWaveView.frame = rect;
                             
                             //                         rect.size.height = CGRectGetHeight(self.frame) - 125 - rect.origin.y;
                             //                         rect.size.width = oriHaloFrame.size.width;
                             //                         NSLog(@"%f", rect.origin.y);
                             //                         _asrHaloView.frame = rect;
                         } completion:^(BOOL finished) {
                             if (_status == TBASRRecording || _status == TBASRLoading)
                             {
                                 [self startWaveAnimation:TBASRWAVEBOTTOM];
                             }
                             else
                             {
                                 isRecordingAni = FALSE;
                             }
                            
                         }];
        
    }
    else
    {
        [UIView animateWithDuration:0.2f delay:0
                            options:UIViewAnimationOptionAllowUserInteraction
                         animations:^{
                             CGRect rect;
                             switch (type) {
//                                 case TBASRWAVETOP:
//                                     rect = micRect;
//                                     rect.origin.y = CGRectGetHeight(self.frame)*.5f - 18.0;
//                                     break;
                                 case TBASRWAVEBOTTOM:
                                     rect = micRect;
                                     rect.origin.y = CGRectGetHeight(self.frame)*.5f+8.0;
                                     break;
                                 case TBASRWAVEUP:
                                     rect = [self calcWaveHeight:_asrWaveView.frame];
                                     break;
                                 case TBASRWAVEDOWN:
                                     rect = _asrWaveView.frame;
                                     rect.origin.y = rect.origin.y + 2.0;
                                     break;
                                 default:
                                     rect = _asrWaveView.frame;
                                     break;
                             }
                             
                             _asrWaveView.frame = rect;
                             
                             //                         rect.size.height = CGRectGetHeight(self.frame) - 125 - rect.origin.y;
                             //                         rect.size.width = oriHaloFrame.size.width;
                             //                         NSLog(@"%f", rect.origin.y);
                             //                         _asrHaloView.frame = rect;
                         } completion:^(BOOL finished) {
                             if (_status == TBASRRecording)
                             {
                                 switch (type) {
                                     case TBASRWAVETOP:
                                         [self startWaveAnimation:TBASRWAVEBOTTOM];
                                         break;
                                     case TBASRWAVEBOTTOM:
                                         [self startWaveAnimation:TBASRWAVEUP];
                                         break;
                                     case TBASRWAVEUP:
                                         [self startWaveAnimation:TBASRWAVEDOWN];
                                         break;
                                     case TBASRWAVEDOWN:
                                         [self startWaveAnimation:TBASRWAVEUP];
                                         break;
                                     default:
                                         break;
                                 }
                             }
                             else if (_status == TBASRLoading)
                             {
                                 [self startWaveAnimation:TBASRWAVEBOTTOM];
                             }
                             else
                             {
                                    isRecordingAni = FALSE;
                             }
                         }];
    }
    
}


// 游标旋转动画
- (void)startLoadingAnimation
{
    CABasicAnimation *_ra = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    _ra.duration = 0.6f;
    _ra.repeatCount = HUGE_VAL;
    _ra.autoreverses = NO;
    _ra.fromValue = [NSNumber numberWithFloat:0];
    _ra.toValue = [NSNumber numberWithFloat:M_PI*2];
    _ra.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    [_asrLoadingView.layer addAnimation:_ra forKey:ASR_LOADING_ANIMATION];
}


// deprecated
/*
 -(void)playSound:(NSString *)name
 {
 NSString *path = [[NSBundle mainBundle] pathForResource:name ofType:@"wav"];
 NSURL *fileURL = [NSURL fileURTBithPath: path isDirectory: NO];
 // 创建音效ID
 SystemSoundID soundID;
 AudioServicesCreateSystemSoundID((__bridge CFURLRef) fileURL, &soundID);
 // 播放声音
 AudioServicesPlaySystemSound(soundID);
 }
 */


- (int)getStatus
{
    return _status;
}

@end