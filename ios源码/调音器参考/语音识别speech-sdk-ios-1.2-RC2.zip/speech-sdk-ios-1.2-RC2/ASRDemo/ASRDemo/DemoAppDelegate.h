//
//  DemoAppDelegate.h
//  ASRDemo
//
//  Created by Shawn Chain on 13-10-30.
//  Copyright (c) 2013年 MTeam. All rights reserved.
//

#import <UIKit/UIKit.h>

//@class DemoViewController;

@interface DemoAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *viewController;

@end
