//
//  TBASRViewController.m
//  Taobao2013
//
//  Created by Raymond Yang on 29/10/13.
//  Copyright (c) 2013 Taobao.com. All rights reserved.
//

#import "LWASRViewController.h"
#import <AVFoundation/AVFoundation.h>

////////////////////////////////////////
#define kTextInputMarginLeft 46
#define kTextInputWidth 184
#define kTextInputHeight 55
#define kTableViewYOffset 10
#define kKeyboardHeight 216
#define kScreenWidth 320

@implementation LWASRViewController

@synthesize recognizer               = _recognizer;
@synthesize asrBoard                 = _asrBoard;
@synthesize asrStartSound            = _asrStartSound;
@synthesize asrGetSound              = _asrGetSound;
@synthesize asrCancelSound           = _asrCancelSound;
@synthesize asrErrorSound            = _asrErrorSound;
@synthesize pluginButton             = _pluginButton;
@synthesize emotionButton            = _emotionButton;
@synthesize voiceButton              = _voiceButton;
@synthesize inputFieldBackgroundView    = _inputFieldBackgroundView;
@synthesize voiceSwitchButton           = _voiceSwitchButton;
@synthesize backgroundView           = _backgroundView;
@synthesize backButton           = _backButton;

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:kStartSoundEndNotiKey
                                                  object:nil];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _backButton = [[UIButton alloc] initWithFrame:
                   CGRectMake(0, 1, 62, 44)];
    [_backButton setBackgroundImage:[UIImage imageNamed:@"nav_icon_back.png"]
                              forState:UIControlStateNormal];
    [_backButton addTarget:self action:@selector(asrBack) forControlEvents:UIControlEventTouchDown];
    _backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"background.png"]];
    int chatviewY = [[UIScreen mainScreen]bounds].size.height - kKeyboardHeight - 20 - kTextInputHeight;
    self.view.backgroundColor = [UIColor whiteColor];
    _inputFieldBackgroundView = [[UIImageView alloc] initWithImage:
                                 [[UIImage imageNamed:@"MessageEntryInputField_msg.png"] stretchableImageWithLeftCapWidth:14
                                                                                                             topCapHeight:22]];
    _inputFieldBackgroundView.frame =
    CGRectMake(kTextInputMarginLeft+2, chatviewY, kTextInputWidth-2, kTextInputHeight);
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:
                              [[UIImage imageNamed:@"MessageEntryBackground.png"] stretchableImageWithLeftCapWidth:13
                                                                                                      topCapHeight:22]];
    imageView.userInteractionEnabled = YES;
    imageView.frame = CGRectMake(0, chatviewY, kScreenWidth, 55);
    
    _asrBoard = [[LWAsrBoard alloc] initWithFrame:CGRectMake(0, chatviewY + kTextInputHeight, kScreenWidth, kKeyboardHeight)];
    _asrBoard.delegate = self;
    [_asrBoard setButtonAvailable:NO];
//    
    _voiceSwitchButton = [[UIButton alloc] initWithFrame:CGRectMake(0, chatviewY + 2, 44, 55)];
    [_voiceSwitchButton setBackgroundImage:[UIImage imageNamed:@"text_switch_button.png"]
                                  forState:UIControlStateNormal];
    
    _emotionButton = [[UIButton alloc] initWithFrame:
                      CGRectMake(320 - 53 - 36 - 1, chatviewY + 2, 44, 55)];
    [_emotionButton setBackgroundImage:[UIImage imageNamed:@"emo_swicth_button.png"]
                              forState:UIControlStateNormal];
    
    _pluginButton = [[UIButton alloc] initWithFrame:
                     CGRectMake(320 - 53 - 3 +8, chatviewY + 2, 44, 55)];
    [_pluginButton setBackgroundImage:[UIImage imageNamed:@"add_swicth_button.png"]
                             forState:UIControlStateNormal];
    
    _textView = [[UILabel alloc] initWithFrame:
                 CGRectMake(kTextInputMarginLeft + 10, chatviewY + 13, kTextInputWidth, 40)];
	_textView.font = [UIFont systemFontOfSize:15.0f];
    _textView.backgroundColor = [UIColor clearColor];
    _textView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    
    [self.view addSubview:_backgroundView];
    [self.view addSubview:imageView];
    [self.view addSubview:_inputFieldBackgroundView];
    [self.view addSubview:_voiceSwitchButton];
    [self.view addSubview:_emotionButton];
    [self.view addSubview:_pluginButton];
    [self.view addSubview:_asrBoard];
    [self.view addSubview:_textView];
    [self.view addSubview:_backButton];
    
    self.recognizer = [[MRecognizer alloc] init];
    self.recognizer.cancelOnAppEntersBackground = YES;
    [self.recognizer setVadAutoStopTimeInterval:2];
    self.recognizer.delegate = self;
    
    _asrStartSound = [[SoundEffect alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"asr_speak_now" ofType:@"wav"] notificationName:kStartSoundEndNotiKey];
    _asrGetSound = [[SoundEffect alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"asr_got_it" ofType:@"wav"]];
    _asrCancelSound = [[SoundEffect alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"asr_cancel" ofType:@"wav"]];
    _asrErrorSound = [[SoundEffect alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"asr_error" ofType:@"wav"]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(asrStartRecord)
                                                 name:kStartSoundEndNotiKey
                                               object:nil];
}

#pragma mark - Recoginzer delegate
-(void) onRecordVoice:(NSData *)voice
{
}

#pragma mark - 语音识别相关
- (void) asrStartAction
{
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    //    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
    //    AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute, sizeof(audioRouteOverride), &audioRouteOverride);
    [_asrStartSound play];
    [_asrBoard startPreAnimation];
}

- (void) asrStartRecord
{
    if ([_asrBoard getStatus] == LWASRRecording && ![_recognizer isStarted]) //避免停止后还启动语音识别，但是还存在多次重入问题，不过，语音识别可以正常运行
    {
        [_recognizer start];
    }
}

- (void) asrStopAction
{
    if (_recognizer && [_recognizer isStarted])
    {
        [_recognizer stop];
    }
    else //如果还未启动录音, 直接停止动画
    {
        [_asrBoard resetView];
        [_asrCancelSound play];
    }
}

- (void) asrCancelAction
{
    if (_recognizer && [_recognizer isStarted])
    {
        [_recognizer cancel];
        [_asrCancelSound play];
    }
    else
    {
        [_asrBoard resetView];
    }
}

-(void) recognizer:(MRecognizer*)recognizer didCompleteRecognizingWithResult:(MRecognizerResult*)result error:(NSError*)error
{
    //语音输入埋点
    [_asrBoard resetView];
    if (!error)
    {
        if (result && result.asrText)
        {
            NSLog(@"get result\n");
            _textView.text = result.asrText;
        }
        else
        {
            NSLog(@"sth other\n");
        }
        
        [_asrGetSound play];
    }
    else
    {
        NSString *errValue = [error.userInfo objectForKey:@"NSLocalizedDescription"];
        NSLog(@"%@", errValue);
        if ([errValue isEqualToString:@"MRecognizerError_UserCancelled"])
        {
            NSLog(@"user cancel\n");
        }
        else if ([errValue isEqualToString:@"MRecognizerErrorNotRecognized"])
        {
            //            [_asrBoard setLabelText:@"录音太短，听不懂说什么"]
            [_asrErrorSound play];
        }
        else
        {
            NSLog(@"sth error\n");
            [_asrErrorSound play];
        }
    }
}

- (void)recognizerDidStartRecording:(MRecognizer*)recognizer
{
    
}

- (void)recognizerDidStopRecording:(MRecognizer*)recognizer
{
    [_asrBoard startLoading];
}

- (void)recognizer:(MRecognizer*)recognizer recordingWithVoiceVolume:(NSUInteger)voiceVolume;
{
    [_asrBoard update:voiceVolume];
}

- (void)recognizerDidStartRecognizing:(MRecognizer*)recognizer
{
}

- (void)recognizerDidStopRecognizing:(MRecognizer*)recognizer
{
}


#pragma mark - LWAsrBoardDelegate Delegate
- (void)asrCleanMsg
{
}

- (void) asrSendMsg
{
}

- (void)asrMicClicked
{
    if([[AVAudioSession sharedInstance] respondsToSelector:@selector(requestRecordPermission:)]){
        [[AVAudioSession sharedInstance] performSelector:@selector(requestRecordPermission:) withObject:^(BOOL granted) {

            if (granted) {
                int status = [_asrBoard getStatus];
                switch (status) {
                    case LWASREnding:
                       [self  asrStartAction];
                       break;
                    case LWASRRecording:
                       [self asrStopAction];
                       break;
                    default:
                       [self asrCancelAction];
                       break;
                 }
            } else {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"record no permission title"
                                                            message:@"record no permission msg"
                                                           delegate:nil
                                                  cancelButtonTitle:nil
                                                  otherButtonTitles:@"confirm", nil];
                [alert show];
            }
        }];
    }
    else
    {
        int status = [_asrBoard getStatus];
        switch (status) {
            case LWASREnding:
                [self  asrStartAction];
                break;
            case LWASRRecording:
                [self asrStopAction];
                break;
            default:
                [self asrCancelAction];
                break;
        }
    }
}

- (void)asrBack
{
    [self dismissModalViewControllerAnimated:YES]; 
}

@end