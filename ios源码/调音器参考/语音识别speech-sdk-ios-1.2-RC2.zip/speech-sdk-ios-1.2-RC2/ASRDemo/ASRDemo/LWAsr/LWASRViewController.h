//
//  LWASRViewController.h
//  Taobao2013
//
//  Created by Raymond Yang on 29/10/13.
//  Copyright (c) 2013 Taobao.com. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <SpeechRecognizer/SpeechRecognizer.h>
#import <AudioToolbox/AudioToolbox.h>

#import "LWAsrBoard.h"
#import "SoundEffect.h"
@interface LWASRViewController : UIViewController <MRecognizerDelegate, LWAsrBoardDelegate> {

}

@property (nonatomic, strong) MRecognizer                  *recognizer;
@property (nonatomic, strong) LWAsrBoard                   * asrBoard; // injection
@property (nonatomic, strong) SoundEffect                  * asrStartSound; // injection
@property (nonatomic, strong) SoundEffect                  * asrGetSound; // injection
@property (nonatomic, strong) SoundEffect                  * asrCancelSound; // injection
@property (nonatomic, strong) SoundEffect                  * asrErrorSound; // injection
@property (nonatomic, strong) UILabel                   * textView;
@property (nonatomic, strong) UIButton                     * voiceButton;
@property (nonatomic, strong) UIButton                     * pluginButton;
@property (nonatomic, strong) UIButton                     * emotionButton;
@property (nonatomic, strong) UIImageView                  * inputFieldBackgroundView;
@property (nonatomic, strong) UIImageView                  * backgroundView;
@property (nonatomic, strong) UIButton                  * voiceSwitchButton;
@property (nonatomic, strong) UIButton                  * backButton;
@end
