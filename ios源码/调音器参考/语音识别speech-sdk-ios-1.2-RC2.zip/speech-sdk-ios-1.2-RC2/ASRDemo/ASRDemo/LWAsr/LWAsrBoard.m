//
//  LWAsrBoard.m
//  Laiwang
//
//  Created by dailin.dl on 13-10-10.
//  Copyright (c) 2013年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import "LWAsrBoard.h"
#import <QuartzCore/QuartzCore.h>

#define ASR_LOADING_ANIMATION @"asr_loading_animation"
#define ASR_WAVE_ANIMATION @"asr_wave_animation"

@implementation LWAsrBoard
@synthesize asrClearButton = _asrClearButton;
@synthesize asrSendButton = _asrSendButton;
@synthesize asrMicView = _asrMicView;
@synthesize asrMicBgView = _asrMicBgView;
@synthesize asrLoadingView = _asrLoadingView;
@synthesize asrWaveView = _asrWaveView;
@synthesize asrGroundView = _asrGroundView;
@synthesize asrBgLayer = _asrBgLayer;
@synthesize asrTipLabel = _asrTipLabel;
@synthesize asrHaloView = _asrHaloView;
@synthesize asrBgView = _asrBgView;
@synthesize asrMicBtn = _asrMicBtn;
@synthesize asrLightView = _asrLightView;

- (void)dealloc
{
    self.asrClearButton = nil;
    self.asrSendButton = nil;
    self.asrMicView = nil;
    
    [_asrLoadingView.layer removeAllAnimations];
    self.asrLoadingView = nil;
    if (self.asrBgLayer)
    {
        [_asrBgLayer removeAllAnimations];
    }
    self.asrBgLayer = nil;
    
    self.asrMicBgView = nil;
    self.asrWaveView = nil;
    self.asrLightView = nil;
    self.asrGroundView = nil;
    self.asrTipLabel = nil;
    self.asrLightView = nil;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self initComponent];
    }
    return self;
}

- (void)initComponent
{
    _asrGroundView = [[UIImageView alloc] initWithFrame: CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, self.frame.size.height)];
    [_asrGroundView setImage:[UIImage imageNamed:@"lw_asr_ground.png"]];
    
    _asrClearButton = [[UIButton alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.frame) - 41 , CGRectGetWidth(self.frame) / 2, 41)];
    [_asrClearButton addTarget:self action:@selector(asrClearClicked) forControlEvents:UIControlEventTouchDown];
    [_asrClearButton setTitle:@"清空" forState:UIControlStateNormal];
    [_asrClearButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
    [_asrClearButton setBackgroundImage:[UIImage imageNamed:@"lw_asr_clean_button.png"] forState:UIControlStateNormal];
    
    _asrSendButton = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetWidth(self.frame) / 2, CGRectGetHeight(self.frame) - 41 , CGRectGetWidth(self.frame) / 2, 41)];
    [_asrSendButton addTarget:self action:@selector(asrSendClicked) forControlEvents:UIControlEventTouchDown];
    [_asrSendButton setTitle:@"发送" forState:UIControlStateNormal];
    [_asrSendButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
    [_asrSendButton setBackgroundImage:[UIImage imageNamed:@"lw_asr_send_button.png"] forState:UIControlStateNormal];
    
    _asrBgView = [[UIImageView alloc] initWithFrame: CGRectMake((CGRectGetWidth(self.frame) - 107) / 2, CGRectGetHeight(self.frame) - 185 , 107, 107)];
    [_asrBgView setImage:[UIImage imageNamed:@"lw_asr_round_dark.png"]];
//    _asrBgView.layer.shouldRasterize = YES;
//    _asrBgView.layer.rasterizationScale = [[UIScreen mainScreen] scale];
    
    _asrMicBgView = [[UIImageView alloc] initWithFrame: CGRectMake((CGRectGetWidth(self.frame) - 107) / 2, CGRectGetHeight(self.frame) - 185 , 107, 107)];
    self.asrBgLayer = [CALayer layer];
    _asrBgLayer.contentsScale = 2;//由于没有单分辨率图，强制指定为2
    _asrBgLayer.contentsGravity=kCAGravityCenter;
    _asrBgLayer.frame = CGRectMake(0, 0 , 107, 107);
    _asrBgLayer.contents=(id) [[UIImage imageNamed:@"lw_asr_round_dark.png"] CGImage];
//    _asrBgLayer.shouldRasterize = YES;
//    _asrBgLayer.rasterizationScale = [[UIScreen mainScreen] scale];
    [_asrMicBgView.layer addSublayer:_asrBgLayer];
    _asrMicBgView.userInteractionEnabled = YES;
    
    _asrMicBtn = [[UIButton alloc] initWithFrame: CGRectMake((CGRectGetWidth(self.frame) - 107) / 2, CGRectGetHeight(self.frame) - 185 , 107, 107)];
    [_asrMicBtn addTarget:self action:@selector(asrMicClicked:) forControlEvents:UIControlEventTouchUpInside];
    [_asrMicBtn setBackgroundImage:[UIImage imageNamed:@"lw_asr_click.png"] forState:UIControlStateHighlighted];
    
    
    _asrLoadingView = [[UIImageView alloc] initWithFrame: CGRectMake((CGRectGetWidth(self.frame) - 107) / 2, CGRectGetHeight(self.frame) - 185 , 107, 107)];
    [_asrLoadingView setImage:[UIImage imageNamed:@"lw_asr_loading.png"]];
    _asrLoadingView.alpha = 0;
    
    oriWaveFrame = CGRectMake((CGRectGetWidth(self.frame) - 16) / 2, CGRectGetHeight(self.frame) - 140 , 16, 30);
    _asrWaveView = [[UIImageView alloc] initWithFrame: oriWaveFrame];
    [_asrWaveView setImage:[UIImage imageNamed:@"lw_asr_wave.png"]];
    _asrWaveView.clipsToBounds = YES;
    _asrWaveView.contentMode = UIViewContentModeBottomLeft;
    
    oriHaloFrame = CGRectMake((CGRectGetWidth(self.frame) - 17) / 2 + 0.5, CGRectGetHeight(self.frame) - 140 , 17, 15);
    _asrHaloView = [[UIImageView alloc] initWithFrame: oriHaloFrame];
    [_asrHaloView setImage:[UIImage imageNamed:@"lw_asr_halo.png"]];
    _asrHaloView.clipsToBounds = YES;
    _asrHaloView.contentMode = UIViewContentModeBottomLeft;
    _asrHaloView.alpha = 0;

    _asrLightView = [[UIImageView alloc] initWithFrame: CGRectMake((CGRectGetWidth(self.frame) - 13) / 2 + 0.5, CGRectGetHeight(self.frame) - 155 , 13, 13)];
    [_asrLightView setImage:[UIImage imageNamed:@"lw_asr_light.png"]];
    
    _asrTipLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    UIFont *font = [UIFont fontWithName:@"Arial" size:15];
    _asrTipLabel.textColor = [UIColor grayColor];
    _asrTipLabel.font = font;
    _asrTipLabel.backgroundColor = [UIColor clearColor];
//    [self setLabelText:@"点击使用语音识别"];
    
    isRecordingAni = FALSE;
    _asrWaveVolume = 0;
    _status = LWASREnding;

    [self addSubview:_asrGroundView];
    [self addSubview:_asrClearButton];
    [self addSubview:_asrSendButton];
    [self addSubview:_asrBgView];
    [self addSubview:_asrWaveView];
    [self addSubview:_asrMicBgView];
    [self addSubview:_asrMicBtn];
    [self addSubview:_asrLoadingView];
    [self addSubview:_asrTipLabel];
    [self addSubview:_asrHaloView];
    [self addSubview:_asrLightView];
}

- (void)asrMicClicked:(id) sender
{
    if(self.delegate)
        [self.delegate asrMicClicked];
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void) asrClearClicked
{
    if(self.delegate)
        [self.delegate asrCleanMsg];
    
    [self setButtonAvailable:false];
}

-(void) asrSendClicked
{
    if(self.delegate)
        [self.delegate asrSendMsg];
    
    [self setButtonAvailable:false];
}

-(void) update:(int)value
{
    _curAsrVolume = value;
}

-(void) setButtonAvailable:(BOOL)type
{
    if (type)
    {
        [_asrClearButton setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
        _asrClearButton.enabled = true;
        [_asrSendButton setTitleColor:[UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1] forState:UIControlStateNormal];
        _asrSendButton.enabled = true;
        
    }
    else
    {
        [_asrClearButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
        _asrClearButton.enabled = false;
        [_asrSendButton setTitleColor:[UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1] forState:UIControlStateNormal];
        _asrSendButton.enabled = false;
    }
}

- (void)startPreAnimation
{
    [_asrLoadingView.layer removeAllAnimations];
    _asrWaveView.frame = CGRectMake((CGRectGetWidth(self.frame) - 16) / 2, CGRectGetHeight(self.frame) - 125 , 16, 30);
    _asrHaloView.frame = CGRectMake((CGRectGetWidth(self.frame) - 17) / 2, CGRectGetHeight(self.frame) - 125 , 17, 0);
    _status = LWASRRecording;
    _asrWaveVolume = 0;
    _asrLoadingView.alpha = 0;

    [CATransaction begin];
    [CATransaction setAnimationDuration:.5f];
    [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
    [CATransaction setCompletionBlock:nil];
    _asrBgLayer.contents=(id) [[UIImage imageNamed:@"lw_asr_round.png"] CGImage];
    [CATransaction commit];
    
    [UIView animateWithDuration:0.5f delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
        _asrHaloView.alpha = 1;
    } completion:nil];
    
    [self setLabelText:@"点击可以结束"];
    if (!isRecordingAni)
    {
        isRecordingAni = TRUE;
        [self startWaveAnimation:LWASRWAVETOP];
    }
}

-(void) startLoading
{
    NSLog(@"startLoading\n");
    _status = LWASRLoading;
    [self startLoadingAnimation];
    _asrLoadingView.alpha = 1.0f;
    _curAsrVolume = 0;
}

- (void)resetView
{
    _status = LWASREnding;
    NSLog(@"resetView\n");
    [self setLabelText:@"点击开始"];

    [UIView animateWithDuration:0.5f delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
        _asrLoadingView.alpha = 0;
        _asrHaloView.alpha = 0;
//        _asrTipLabel.alpha = 1;
    } completion:nil];
    
    [CATransaction begin];
    [CATransaction setAnimationDuration:.5f];
    [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
    [CATransaction setCompletionBlock:nil];
    _asrBgLayer.contents=(id) [[UIImage imageNamed:@"lw_asr_round_dark.png"] CGImage];
    [CATransaction commit];
}

- (CGRect)calcWaveHeight:(CGRect) rect
{
    _asrWaveVolume = _curAsrVolume;
    if (_asrWaveVolume <= 50) {
        rect.origin.y = CGRectGetHeight(self.frame) - 140;
    }else if (_asrWaveVolume <= 55) {
        rect.origin.y = CGRectGetHeight(self.frame) - 142;
    }else if (_asrWaveVolume <= 60) {
        rect.origin.y = CGRectGetHeight(self.frame) - 144;
    }else if (_asrWaveVolume <= 65) {
        rect.origin.y = CGRectGetHeight(self.frame) - 146;
    }else if (_asrWaveVolume <= 70) {
        rect.origin.y = CGRectGetHeight(self.frame) - 148;
    }else if (_asrWaveVolume <= 72) {
        rect.origin.y = CGRectGetHeight(self.frame) - 150;
    }else if (_asrWaveVolume <= 74) {
        rect.origin.y = CGRectGetHeight(self.frame) - 152;
    }else if (_asrWaveVolume <= 76) {
        rect.origin.y = CGRectGetHeight(self.frame) - 154;
    }else if (_asrWaveVolume <= 78) {
        rect.origin.y = CGRectGetHeight(self.frame) - 156;
    }else if (_asrWaveVolume <= 96) {
        rect.origin.y = CGRectGetHeight(self.frame) - 156;
    }else
    {
        rect.origin.y = CGRectGetHeight(self.frame) - 156;
    }
    
    return rect;
}

- (void)startWaveAnimation:(LWASRWAVEAnimationTYPE)type
{
    if (type == LWASRWAVETOP)
    {
        [UIView animateWithDuration:0.3f delay:0
                            options:UIViewAnimationOptionCurveLinear
                         animations:^{
                             CGRect rect;
                             
                             rect = oriWaveFrame;
                             rect.origin.y = CGRectGetHeight(self.frame) - 156;
                             _asrWaveView.frame = rect;
                             
                             rect.size.height = CGRectGetHeight(self.frame) - 125 - rect.origin.y;
                             rect.size.width = oriHaloFrame.size.width;
//                             NSLog(@"%f", rect.origin.y);
                             _asrHaloView.frame = rect;
                         } completion:^(BOOL finished) {
                             [self startWaveAnimation:LWASRWAVEBOTTOM];
                         }];
    }
    else
    {
        [UIView animateWithDuration:0.15f delay:0
                            options:UIViewAnimationOptionCurveLinear
                         animations:^{
                             CGRect rect;
                             switch (type) {
                                 case LWASRWAVETOP:
                                     rect = oriWaveFrame;
                                     rect.origin.y = CGRectGetHeight(self.frame) - 156;
                                     break;
                                 case LWASRWAVEBOTTOM:
                                     rect = oriWaveFrame;
                                     rect.origin.y = CGRectGetHeight(self.frame) - 138;
                                     break;
                                 case LWASRWAVEUP:
                                     rect = [self calcWaveHeight:_asrWaveView.frame];
                                     break;
                                 case LWASRWAVEDOWN:
                                     if (_asrWaveVolume == _curAsrVolume)
                                     {
                                         rect = _asrWaveView.frame;
                                         rect.origin.y = rect.origin.y + 2;
                                     }
                                     else
                                     {
                                         rect = [self calcWaveHeight:_asrWaveView.frame];
                                     }
                                     break;
                                 default:
                                     rect = _asrWaveView.frame;
                                     break;
                             }
                             
                             _asrWaveView.frame = rect;
                             
                             rect.size.height = CGRectGetHeight(self.frame) - 125 - rect.origin.y;
                             rect.size.width = oriHaloFrame.size.width;
//                             NSLog(@"%f", rect.origin.y);
                             _asrHaloView.frame = rect;
                         } completion:^(BOOL finished) {
                             if (_status == LWASRRecording)
                             {
                                 switch (type) {
                                     case LWASRWAVETOP:
                                         [self startWaveAnimation:LWASRWAVEBOTTOM];
                                         break;
                                     case LWASRWAVEBOTTOM:
                                         [self startWaveAnimation:LWASRWAVEUP];
                                         break;
                                     case LWASRWAVEUP:
                                         [self startWaveAnimation:LWASRWAVEDOWN];
                                         break;
                                     case LWASRWAVEDOWN:
                                         [self startWaveAnimation:LWASRWAVEUP];
                                         break;
                                     default:
                                         break;
                                 }
                             }
                             else if (_status == LWASRLoading)
                             {
                                 [self startWaveAnimation:LWASRWAVEBOTTOM];
                             }
                             else
                             {
                                 NSLog(@"startWaveAnimation end");
                                 isRecordingAni = FALSE;
                             }
                         }];
    }
}

- (void)startLoadingAnimation
{
    CABasicAnimation *_ra = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    _ra.duration = 0.6f;
    _ra.repeatCount = HUGE_VAL;
    _ra.autoreverses = NO;
    _ra.fromValue = [NSNumber numberWithFloat:0];
    _ra.toValue = [NSNumber numberWithFloat:M_PI*2];
    _ra.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    [_asrLoadingView.layer addAnimation:_ra forKey:ASR_LOADING_ANIMATION];
}

- (int)getStatus
{
    return _status;
}

- (void)setLabelText:(NSString *)str
{
    UIFont *font = [UIFont fontWithName:@"Arial" size:15];
    CGSize labelsize = [str sizeWithFont:font constrainedToSize:CGSizeMake(320,2000) lineBreakMode:NSLineBreakByWordWrapping];
    CGRect rct = _asrTipLabel.frame;
    rct.size = labelsize;
    _asrTipLabel.frame = rct;
    _asrTipLabel.center = CGPointMake(160, CGRectGetHeight(self.frame) - 60);
    [_asrTipLabel setText:str];
    
//    [UIView animateWithDuration:0.2f delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
//        _asrTipLabel.alpha = 0;
//                     } completion:^(BOOL finished) {
//
//
//                         [UIView animateWithDuration:0.2f delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
//                            _asrTipLabel.alpha = 1;
//                         } completion:nil];
//                     }];
}

@end
