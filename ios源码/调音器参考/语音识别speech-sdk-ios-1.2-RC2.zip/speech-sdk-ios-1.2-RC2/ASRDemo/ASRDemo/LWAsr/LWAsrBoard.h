//
//  LWAsrBoard.h
//  Laiwang
//
//  Created by dailin.dl on 13-10-10.
//  Copyright (c) 2013年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LWAsrBoardDelegate <NSObject>
- (void) asrCleanMsg;
- (void) asrSendMsg;
- (void) asrMicClicked;
@end

typedef enum {
    LWASRRecording = 0,
    LWASRLoading,
    LWASREnding
} LWASRAnimationStatus;

typedef enum {
    LWASRWAVETOP = 0,
    LWASRWAVEBOTTOM,
    LWASRWAVEUP,
    LWASRWAVEDOWN
} LWASRWAVEAnimationTYPE;

@interface LWAsrBoard : UIView
{
    int _status;
    int _asrWaveVolume;
    int _curAsrVolume;
    CGRect oriWaveFrame;
    CGRect oriHaloFrame;
    BOOL isRecordingAni;
}

@property (nonatomic, strong) UIButton       *asrClearButton;
@property (nonatomic, strong) UIButton       *asrSendButton;
@property (nonatomic, strong) UIImageView    *asrMicView;
@property (nonatomic, strong) UIImageView    *asrMicBgView;
@property (nonatomic, strong) UIButton       *asrMicBtn;
@property (nonatomic, strong) UIImageView    *asrBgView;
@property (nonatomic, strong) UIImageView    *asrLoadingView;
@property (nonatomic, strong) UIImageView    *asrWaveView;
@property (nonatomic, strong) UIImageView    *asrLightView;
@property (nonatomic, strong) UIImageView    *asrGroundView;
@property (nonatomic, strong) UIImageView    *asrHaloView;
@property (nonatomic, strong) UILabel        *asrTipLabel;
@property (nonatomic, strong) CALayer        *asrBgLayer;
@property (nonatomic, assign) id<LWAsrBoardDelegate>    delegate;

- (void)update:(int) value;
- (void)resetView;
- (void)startLoading;
- (void)startPreAnimation;
- (void)setButtonAvailable:(BOOL)type;
- (int)getStatus;

@end
