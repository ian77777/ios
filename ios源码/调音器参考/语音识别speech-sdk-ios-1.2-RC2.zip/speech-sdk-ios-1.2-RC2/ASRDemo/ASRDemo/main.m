//
//  main.m
//  ASRDemo
//
//  Created by Shawn Chain on 13-10-30.
//  Copyright (c) 2013年 MTeam. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DemoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DemoAppDelegate class]));
    }
}
