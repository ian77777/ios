//
//  MRecognizer.h
//  Recognizer
//
//  Created by Shawn Chain on 13-10-30.
//  Copyright (c) 2013年 MTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

/** 
 * 服务状态改变通知
 * @discussion 当远端服务状态发生变化的时候，发出该通知。开发者可以根据测返回值，调整UI行为。
 * object 类型[NSNumber numberWithBool:vailable]，标示主服务是否可用。
 * userInfo 包含详细的每个服务的状态：{name: [NSNumber numberWithBool:vailable]}。
 */
extern NSString * const kMRecognizerServiceStatusChanged;

/**
 * ASR主服务
 * @discussion 流式调用，同步翻译
 */
extern NSString * const kMRecognizerServiceNameASR;
/**
 * ASR RPC服务
 * @discussion 离线翻译，目前只有来往使用
 */
extern NSString * const kMRecognizerServiceNameASRRPC;
/**
 * NLP服务
 */
extern NSString * const kMRecognizerServiceNameNLP;

/**
 * SDK版本号
 */
extern NSString * const kMRecognizerVersion;

/////////////////////////////////////////////////////////////////////////
// Error definitions
/////////////////////////////////////////////////////////////////////////
/**
 * 错误代码
 */
typedef enum{
    kERR_NO_ERROR = 0,
    kERR_GENERIC_ERROR = 1,
    kERR_USER_CANCELED = 520, // 用户取消
    kERR_NETWORK_ERROR = 530, // 网络及通讯异常
    kERR_SERVICE_ERROR = 540, // 语音服务异常或被降级
    kERR_VOICE_ERROR = 550,   // 录音及语音识别异常
    kERR_MIC_ERROR = 560,     // Mic无法访问或硬件异常
    kERR_TOOSHORT_ERROR = 570,  // 用户点击过快
} kMRecognizerErrorCode;

/////////////////////////////////////////////////////////////////////////
// Mode definitions
/////////////////////////////////////////////////////////////////////////
/**
 * SDK模式
 */
typedef enum{
    kMODE_RECOGNIZER = 0, // 默认模式，用于语音识别
    kMODE_RECORDER = 1, // 录音模式，不进行识别，可回调录音得到的数据
} kMRecognizerMode;
/////////////////////////////////////////////////////////////////////////

#pragma mark - Recognizer Delegate
/////////////////////////////////////////////////////////////////////////
@class MRecognizer;
@class MRecognizerResult;

/**
 *@discussion Recognizer的回调接口
 */
@protocol MRecognizerDelegate <NSObject>


@required
/**
 *@discussion 语音识别的关键回调函数，delegate必须实现。
 *
 *@param recognizer
 *@param result MRecognizerResult 返回值对象
 *@param error  NSError 识别错误和异常
 */
-(void) recognizer:(MRecognizer*)recognizer didCompleteRecognizingWithResult:(MRecognizerResult*)result error:(NSError*)error;

@optional

/**
 *@discussion 返回录音的语音音量，调用频率取决于SDK内部设定。
 *@param recognizer
 *@param voiceVolume 0-100的数值
 */
-(void) recognizer:(MRecognizer*)recognizer recordingWithVoiceVolume:(NSUInteger)voiceVolume;

/**
 *@discussion 开始录音的回调通知
 */
-(void) recognizerDidStartRecording:(MRecognizer*)recognizer;


/**
 *@discussion 停止录音的回调通知
 */
-(void) recognizerDidStopRecording:(MRecognizer*)recognizer;

/**
 *@discussion 录音模式下停止的回调通知，可得到录音数据
 */
-(void) recognizerDidStopRecording:(MRecognizer*)recognizer withRecorderData:(NSData*)data;
@end



/////////////////////////////////////////////////////////////////////////
#pragma mark - Recognizer Interface
/////////////////////////////////////////////////////////////////////////

/**
 * MRecognizer
 *
 * @discussion 语音识别SDK的核心类，封装了录音设备的初始化，压缩处理，语音检测（VAD）等复杂逻辑，自动的将语音数据同步传送到ASR WebService。开发者只需要传递正确delegate的，就能完成语音识别
 *
 */
@interface MRecognizer : NSObject

/**
 * Recognizer delegate
 * @discussion 语音识别结果返回或者发生异常的回调接口 MRecognizerDelegate
 */
@property(nonatomic,assign) id<MRecognizerDelegate> delegate;

/**
 * SDK工作模式设置
 * @discussion 语音SDK的工作模式，若不设置，则为kMODE_RECOGNIZER
 */
@property(nonatomic,assign,readwrite) kMRecognizerMode mode;

/**
 * Minmal speech length to start recognize
 * @discussion 语音识别所需的最小长度，缺省0.4秒。在开始识别之前设定有效。如果用户语音小于这个长度，则识别失败，返回错误代码为kERR_VOICE_ERROR,错误信息为kMRecognizerErrorNotRecognized
 */
@property(nonatomic,assign,readwrite) float minimalSpeechLength;

/**
 * cancel on app enters background
 *@discussion 缺省为NO. 如果设为YES，则SDK会监听App状态，一旦切换到后台，就自动取消请求。
 */
@property(nonatomic,assign,readwrite) BOOL cancelOnAppEntersBackground;

/**
 * disable user cancel callback
 *@discuss MRecognizer的cancel方法被调用的时候，会触发delegate的onRecognizeComplete方法，错误码为kERR_USER_CANCELED,错误信息为kMRecognizerErrorUserCanceled。如果App不想被回调，请设置为YES即可。参见 cancel方法。
 */
@property(nonatomic,assign,readwrite) BOOL enableUserCancelCallback;

/**
 * enable voice log for debug purpose
 *@discuss 打开语音记录功能，SDK将会把语音识别的文件记录到当前App的document下面，调试用。缺省关闭，在DEBUG模式下有效，Release模式下无效。
 */
@property(nonatomic,assign,readwrite) BOOL enableVoiceLog;


/**
 * 用特定appKey来初始化MRecognizer
 * @param appKey 设定的appKey必须提前通过configure函数预先配置好
 */
-(id)initWithAppkey:(NSString*)appKey;

/**
 * Auto stop time interval
 *@discuss 检测到用户语音后，自动停止的间隙。
 *
 * @param timeinterval 静音触发自动停止的时长，以秒表示.缺省0.7s
 */
-(void)setVadAutoStopTimeInterval:(NSTimeInterval) timeinterval;

/**
 *
 * @discussion 配置语音识别服务模块的基础参数，请在App启动的时候调用.
 *
 * @param appKey
 * @param appSecret
 *
 */
+(void)configureAppKey:(NSString*)appKey appSecret:(NSString*)appSecret;

/**
 *
 * @discussion 配置语音识别服务模块的基础参数，并指定服务地址。请在App启动的时候调用。
 *
 * @param appKey
 * @param appSecret
 * @param serviceURL 服务地址
 *
 */
+(void)configureAppKey:(NSString*)appKey appSecret:(NSString*)appSecret serviceURL:(NSString*)serviceURL;

/**
 *@discussion More advanced configuration
 */
+(void)configureAppKey:(NSString*)appKey appSecret:(NSString*)appSecret serviceURL:(NSString*)serviceURL statusURL:(NSString*)statusURL deviceId:(NSString*)deviceId;

/**
 *
 * @discussion 配置语音识别服务模块的基础参数，并指定服务地址和appKey、appSecret数组。请在App启动的时候调用。
 *
 * @param appKeys       appKey数组，必须与appSecrets一一对应。
 * @param appSecrets    appSecret数组。
 * @param serviceURL    服务地址。
 * @param statusURL     服务检测地址。用于查看当前语音服务是否可用。可以为nil。
 * @param deviceId      设备id。可以为nil。
 *
 */
+(void)configureAppKeys:(NSArray*)appKeys appSecrets:(NSArray*)appSecrets serviceURL:(NSString*)serviceURL statusURL:(NSString*)statusURL deviceId:(NSString*)deviceId;

/**
 * ASR主服务是否可用
 *
 * @discussion 返回ASR主服务当前是否可用。开发者可以根据测返回值，调整UI行为
 */
+ (BOOL) isServiceAvailable;

/*
 * ASR相关服务是否可用
 *
 * @discussion 返回ASR相关服务是否可用
 * 
 * @param serviceName 要检查的服务名。如：`kMRecognizerServiceNameASR`、`kMRecognizerServiceNameASRRPC`、`kMRecognizerServiceNameNLP`
 */
+ (BOOL) isServiceAvailableWithServiceName:(NSString*)serviceName;

/**
 * 开始语音识别
 * @discussion 打开录音设备，同时开始识别
 */
-(void)start;

/**
 * 停止语音识别
 * @discussion 停止录音设备，delegate的didStopRecord会被回调。网络请求在后台继续，如果有识别结果返回，则会通过delegate的didCompleteRecognizingWithResult回调方法单独返回。
 */
-(void)stop;

/**
 * 取消语音识别
 * @discussion 取消语音识别，录音会停止，网络请求会取消。根据enableUserCancelCallback的设置，决定是否回掉delegate方法。
 */
-(void)cancel;

/**
 * 语音识别中
 */
-(BOOL)isStarted;
@end
