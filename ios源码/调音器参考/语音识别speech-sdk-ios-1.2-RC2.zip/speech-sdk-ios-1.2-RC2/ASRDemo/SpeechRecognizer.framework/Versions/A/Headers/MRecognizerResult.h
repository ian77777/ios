//
//  MRecognizerResult.h
//  SpeechRecognizer
//
//  Created by Shawn Chain on 13-11-7.
//  Copyright (c) 2013年 Alibaba MTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

/////////////////////////////////////////////////////
#pragma mark - RecognizeResult
/////////////////////////////////////////////////////

/**
 * MRecognizerResult
 *@discussion封装了返回值对象
 *
 */
@interface MRecognizerResult : NSObject

/**
 *@discussion ASR识别后的返回结果,字符串
 */
@property(nonatomic,readonly) NSString *asrText;

/**
 *@discussion NLP处理后的返回结果,是一个包含MRecognizerNLPIntent的NSArray对象
 */
@property(nonatomic,readonly) NSArray *nlpIntents;
@end

