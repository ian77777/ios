//
//  MRecognizerNLPIntent.h
//  SpeechRecognizer
//
//  Created by Shawn Chain on 13-11-8.
//  Copyright (c) 2013年 Alibaba MTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

/////////////////////////////////////////////////////
#pragma mark - MRecognizerNLPResult
/////////////////////////////////////////////////////

/**
 * MRecognizerNLPResult
 * @discussion NLP处理后的结果对象。参见 http://confluence.taobao.ali.com/x/AQmDD
 */
@interface MRecognizerNLPIntent : NSObject
/**
 * NLP结果名
 */
@property(nonatomic,readonly)NSString* name;
/**
 * NLP结果数据
 * @discussion 以Dict形式保存的key/value对
 */
@property(nonatomic,readonly)NSDictionary* data;

@end

/**
 * MRecognizerNLPSearchIntent
 *
 * @discussion NLP处理后的结果对象子类型，认定为搜索意图。包含搜索关键词。
 */
@interface MRecognizerNLPSearchIntent : MRecognizerNLPIntent
/**
 * 搜索关键词
 *@discussion 语音识别后，经过NLP处理，分词后的搜索关键词
 */
@property(nonatomic,readonly)NSString* keywords;
@end

/**
 * MRecognizerNLPTicketIntent
 *
 * @discussion NLP处理后的结果对象子类型，认定为买机票意图。包含出发地、目的地、日期。
 */
@interface MRecognizerNLPTicketIntent : MRecognizerNLPIntent
/**
 * 机票关键词
 *@discussion 语音识别后，经过NLP处理得到的出发地
 */
@property(nonatomic,readonly)NSString* departureCity;
/**
 * 机票关键词
 *@discussion 语音识别后，经过NLP处理得到的目的地
 */
@property(nonatomic,readonly)NSString* arrivalCity;
/**
 * 机票关键词
 *@discussion 语音识别后，经过NLP处理得到的日期
 */
@property(nonatomic,readonly)NSString* departureDate;
@end

/**
 * MRecognizerNLPChargeIntent
 *
 * @discussion NLP处理后的结果对象子类型，认定为充值意图。包含手机号和充值金额。
 */
@interface MRecognizerNLPChargeIntent : MRecognizerNLPIntent
/**
 * 充值关键词
 *@discussion 语音识别后，经过NLP处理得到的手机号
 */
@property(nonatomic,readonly)NSString* phonenum;
/**
 * 充值关键词
 *@discussion 语音识别后，经过NLP处理得到的充值金额
 */
@property(nonatomic,readonly)NSString* amount;
@end

/**
 * MRecognizerNLPLotteryIntent
 *
 * @discussion NLP处理后的结果对象子类型，认定为买彩票意图。包含类型、数量和日期。
 */
@interface MRecognizerNLPLotteryIntent : MRecognizerNLPIntent
/**
 * 彩票关键词
 *@discussion 语音识别后，经过NLP处理得到的彩票类型
 */
@property(nonatomic,readonly)NSString* lotteryType;
/**
 * 彩票关键词
 *@discussion 语音识别后，经过NLP处理得到的数量
 */
@property(nonatomic,readonly)NSString* lotteryCount;
/**
 * 彩票关键词
 *@discussion 语音识别后，经过NLP处理得到的日期
 */
@property(nonatomic,readonly)NSString* lotteryDate;
@end